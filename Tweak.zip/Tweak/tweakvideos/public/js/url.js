var local = "http://localhost:5003/";
var development = "http://development.myappdemo.net:3002/";
var production = "http://tweakvideos.herokuapp.com/";

var newserver="http://myappdemo.com:5003/";

module.exports = production;
