var apn = require('apn');
var gcm = require('android-gcm');


export default function notification( devicetype, devicetoken, alert, userid, action, profilepic,  tweakimage, youtubeimage, tweakid ) {

   //'b10c7a53ffb348311445a6da58fc18fc870942f7148b7d59d19a25a624a2082f'
//'2898ea9242cf1781ba4a10f038a00f4d158acc9d26ff3f7002f19441befce1ec'    
    //'APA91bHvLuG43sbiufy_SAjyvTJ_BZGEMR22IzG54KFQshpxJS8ITEezKfvtF0OcnQN74keT5ivRcnRltOYnjtZgx6JC1y8ocjF0FPvRQxompeZ7bzHmQ7lQrxgiHbVeBu7C94Qp0CtN'
    if(devicetoken != "(null)") {
        var androidApiKey="AIzaSyCjKzaNM8UeEzuigXG-Qb6nZQ1GopRhwvA";
        
        if(devicetype == "ios"){
            var myDevice = new apn.Device(devicetoken);

            var note = new apn.Notification();
            note.badge = 1;
            note.sound = "notification-beep.wav";

            note.alert = alert;

            note.device = myDevice;

            note.payload = { 'action': action, 'userid': userid, 'profilepic': profilepic, 'tweakid':tweakid };

            var callback = function (errorNum, notification) {
                console.log('Error is: %s', errorNum);
            }
            var options = {
                gateway: 'gateway.push.apple.com',
                //'gateway.sandbox.push.apple.com', 
                // this URL is different for Apple's Production Servers and changes when you go to production
                errorCallback: callback,
                cert: __dirname.split('src/')[0] + '/../../ios_support/apns-tweak-cert.pem',
                key: __dirname.split('src/')[0] + '/../../ios_support/apns-tweak-key.pem',
                passphrase: '4emc912',
                port: 2195,
                cacheLength: 100
            }

            var apnsConnection = new apn.Connection(options);
            apnsConnection.sendNotification(note);
        }
        else if(devicetype == "android"){

            var gcmObject = new gcm.AndroidGcm(androidApiKey);
            var message = new gcm.Message({
                registration_ids: [devicetoken],
                data: {
                    body: alert,
                    action: action,
                    userid: userid,
                    profilepic: profilepic, 
                    tweakid: tweakid
                }
            });

            gcmObject.send(message, function(err, response) {
                if(err) console.error("error: "+err);
        //        else    console.log("response: "+response);
            });
        }
    }
}