import React from 'react';
import {IndexRoute, Route} from 'react-router';

import Main from '../components/Main';
import ChangePassword from '../components/ChangePassword';
import Watch from '../components/Watch';

import Login from '../components/Login';
import Users from '../components/Users';
import Tweaks from '../components/Tweaks';
import Alert from '../components/Alert';
import Categories from '../components/Categories';

export default (
	<Route name="app" path="/" component={Main}>
        <IndexRoute  component={Login} />
        <Route path="/resetpassword/:id" component={ChangePassword} />
        <Route path="/watch/:id" component={Watch} />
    
        <Route path="users" component={Users}/>
        <Route path="tweaks" component={Tweaks}/>
        <Route path="alert" component={Alert}/>
        <Route path="categories" component={Categories}/>
	</Route>
);