import React from 'react';
import Avatar from 'material-ui/lib/avatar';
import Dialog from 'material-ui/lib/dialog';
import FlatButton from 'material-ui/lib/flat-button';
import _ from 'underscore';

import mainurl from '../../public/js/url.js';

const customContentStyle = {
    width: '100%',
    maxWidth: '550px',
    overflowX: 'scroll',
    height: '100%',
    maxHeight: '1000px'
};

class Users extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            users:[],
            usersCount: 0,
            start: 0,
            usersBackUp:[],
            loading: true,
            page: 0,
            displayingUsers: [],
            flaggedTweaks: [],
            open: false,
            openNotification: false,
            notificationLength: 0,
            notificationTo: '',
            searchstring: ''
        };
    }
    
    componentWillMount()
    {
        this.getUsers();
    }
    
    handlePopularChange(_id,e, index, value)
    {
        
    }

    getUsers()
    { 
        this.setState({loading: true});
        
        var data = "{usersList(start: "+ this.state.start +"){_id, name, username, email, profilepic, gender, age, biodata, location, popular, tweakcount, created, viewsCount, bombedCount, lastlogin, logintype, status, flaggedcount, count, likesCount, followersCount, followingCount }}";
        $.ajax
        ({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data ,
            dataType : 'json',
            success:(data) => {
            //    console.log(JSON.stringify(data));
                var array = data.data.usersList;
                if(array != "")
                    this.setState({usersCount: array[0].count});
                this.setState({users: array, loading: false, page: 1},()=>{
                    $('.editabletd').hide();  
                    $('.sort').hide();
                });
            },
            error:(err) => {
                console.log(JSON.stringify(err));
            }
        });
    } 
    
    editUser(user, e) {
        if($('#'+user._id+"editbutton").html() == "Edit") {
            $("#"+user._id+"selectstatus").val(user.status);
            $("#"+user._id+"selectpopular").val(user.popular);
            $('#'+user._id+"statusstatic").hide();
            $('#'+user._id+"popularstatic").hide();
            $('#'+user._id+"statusedit").show();
            $('#'+user._id+"popularedit").show();
            $('#'+user._id+"editbutton").html('Save');
        }
        else {
            $('#'+user._id+"statusstatic").show();
            $('#'+user._id+"popularstatic").show();
            $('#'+user._id+"statusedit").hide();
            $('#'+user._id+"popularedit").hide();
            $('#'+user._id+"editbutton").html('Edit');
            
            var popular = $('#'+user._id+"selectpopular").val();
            var status =  $('#'+user._id+"selectstatus").val();
            
            var data = "mutation M{updateUserAdmin(_id:\""+user._id+"\", status: "+status+", popular: "+popular+"){_id,message}}";
     //       console.log(data)
            $.ajax({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data ,
                dataType : 'json',
                success:(data) => {
                    var users = this.state.users;
                    this.state.users.map((userRecord,key) =>{
                        if(userRecord._id == user._id)
                        {
                            users[key].popular = popular;
                            users[key].status = status;
                            this.setState({users:users});
                        }
                    });
                  /*  
                    var usersBackUp = this.state.usersBackUp;
                    this.state.usersBackUp.map((userRecord,key) =>{
                        if(userRecord._id == user._id)
                        {
                            usersBackUp[key].popular = popular;
                            usersBackUp[key].status = status;
                            this.setState({usersBackUp:usersBackUp});
                        }
                    }); */
                },
                error:(err) => {
                    console.log(JSON.stringify(err));
                }
            });
        }
//      $("#"+user._id+"select").val("2");
//       $('#'+user._id+"popular").html('Whatever HTML you want here. popular');       
    }

    userSearch(search) {
        this.setState({loading: true});
        var data = "{searchUser(searchstring: \""+search+"\",start: "+this.state.start+",limit:20){_id, name, username, email, profilepic, gender, age, biodata, location, popular, tweakcount, created, viewsCount, bombedCount, lastlogin, logintype, status, flaggedcount, count, likesCount, followersCount, followingCount}}";
        $.ajax
        ({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data ,
            dataType : 'json',
            success:(data) => {
            //    console.log(JSON.stringify(data));
                var array = data.data.searchUser;
                if(array != "")
                    this.setState({usersCount: array[0].count});
                this.setState({users: array, loading: false, page: 1},()=>{
                    $('.editabletd').hide();  
                });
            },
            error:(err) => {
                console.log(JSON.stringify(err));
            }
        });
    }
    
    searchUser() {
        var search = this.state.searchstring;
        if(search == "") {
            this.setState({start: 0},()=>{
                this.getUsers();
                $('.editabletd').hide();  
            });
        }
        else {
            this.setState({start: 0},()=>{
                this.userSearch(search);
            })
        }
        $('.sort').hide();
    }
    
    handleChange(type,e) {
        var change = {};
        change[type] = e.target.value;
        this.setState(change)
    }
    
    pagination(val, e) {
        var search = this.state.searchstring;
        if(val == 'first') {
            if(this.state.start != 0)
                this.setState({start: 0},()=>{
                    if(search == "")
                        this.getUsers();
                    else
                        this.userSearch(search);
                });
        }
        else if(val == 'previous') {
            if(this.state.start != 0)
                this.setState({start: this.state.start - 20},()=>{
                    if(search == "")
                        this.getUsers();
                    else
                        this.userSearch(search);
                });
        }
        else if(val == 'next') {
            if(this.state.start + 20 < this.state.usersCount)
                this.setState({start: this.state.start + 20},()=>{
                    if(search == "")
                        this.getUsers();
                    else
                        this.userSearch(search);
                });
        }
        else if(val == 'last') {
            var val = Math.floor((this.state.usersCount-1)/10)
            if(val % 2 != 0)
                val--;
            var last = val*10;
            if(this.state.start != last)
                this.setState({start: last},()=>{
                    if(search == "")
                        this.getUsers();
                    else
                        this.userSearch(search);
                });
        }
    } 
    
    
  /*  
    pagination(val, e) {
        console.log(val);
        var page = this.state.page;
        var pages = Math.ceil(this.state.users.length/20);
        if(val == 'first')
            this.setState({displayingUsers: this.state.users.slice(0,20), page:1});
        else if(val == 'previous') {
            if(page != 1)
                this.setState({displayingUsers: this.state.users.slice(20*(page-2),20*(page-1)), page:page-1});
        }
        else if(val == 'next') {
            if(pages > page)
                this.setState({displayingUsers: this.state.users.slice(20*page,20*(page+1)), page:page+1});
        }
        else if(val == 'last') {
            if(page != pages)
                this.setState({displayingUsers: this.state.users.slice(20*(pages-1),20*(pages)), page:pages});
        }
        $('.editabletd').hide();
        $('.statictd').show();
        $('.editbutton').html('Edit');
    }
  */  
    
    sort_by(field, reverse, primer) {

       var key = primer ? 
           function(x) {return primer(x[field])} : 
           function(x) {return x[field]};

       reverse = !reverse ? 1 : -1;

       return function (a, b) {
           return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
         } 
    }
    
    getSortedUsers(search, order, key) {
        this.setState({loading: true});
        var data = "{sortedUsers(start: " + this.state.start + ", searchstring:\"" + search + "\", order:" + order + ", key:\"" + key + "\"){_id, name, username, email, profilepic, gender, age, biodata, location, popular, tweakcount, created, viewsCount, bombedCount, lastlogin, logintype, status, flaggedcount, count, likesCount, followersCount, followingCount}}";
        console.log(data);
        $.ajax
        ({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data ,
            dataType : 'json',
            success:(data) => {
            //    console.log(JSON.stringify(data));
                var array = data.data.sortedUsers;
                if(array != "")
                    this.setState({usersCount: array[0].count});
                this.setState({users: array, loading: false, page: 1},()=>{
                    $('.editabletd').hide();  
                });
            },
            error:(err) => {
                console.log(JSON.stringify(err));
            }
        });
    
    }
    
    sorting(val, e) {
        console.log(val);
        var array = [];
        var search = this.state.searchstring;
        var order;
        
        if($('#'+val+'asc').css("display") == "none") {
            $('.sort').hide();
            $('#'+val+'asc').show();
            order = 1;
        }
        else {
            $('.sort').hide();
            $('#'+val+'dsc').show();
            order = -1;
        }
        
        this.getSortedUsers(search, order, val);
        
        $('.editabletd').hide();
        $('.statictd').show();
        $('.editbutton').html('Edit');
    }
    
    flaggedTweaks(user, e) {
        if(user.flaggedcount) {
            this.setState({open: true});
            var data = "{flaggedTweaks(_id:\""+user._id+"\"){_id,title}}";
            $.ajax({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data ,
                dataType : 'json',
                success:(data) => {
                    console.log(JSON.stringify(data))
                    console.log(data.data.flaggedTweaks)
                    this.setState({flaggedTweaks: data.data.flaggedTweaks})
                }
            })
        }
        else this.alert('No video is flagged of this user.');
    }
    
    closeFlaggedTweaks() {
        this.setState({open: false});
    }
    
    alert(message) {
        $.alert(message, {
                closeTime: 5000,
                autoClose: true,
                position: ['top-right', [-0.42, 0]],                
                type: 'danger'
            });
    }
    
    notificationChange() {
        this.setState({notificationLength: this.refs.notification.value.length})
    }
    
    openDialog(user, e) {
        this.setState({notificationTo: user})
        this.setState({openNotification: true},() => {
            this.refs.notification.focus();
        });
    }
    
    closeDialog() {
        this.setState({openNotification: false});
    }
    
    sendNotification() {
        this.closeDialog();
        this.setState({notificationLength: 0});
        console.log(this.refs.notification.value);
        var data = "{individualNotification(_id: \""+ this.state.notificationTo._id +"\"notification:\""+this.refs.notification.value+"\"){_id,message}}";
        $.ajax({
        type: "POST",
        url: mainurl,
        contentType: "application/graphql",
        data: data ,
        dataType : 'json',
        success:(data) => {
           console.log(JSON.stringify(data));
           //alert("Message sent successfully");
        },
        error:(err) => {
            console.log(JSON.stringify(err));
          }
        });
    }

    render()
    {   
        if(this.state.loading) 
            return (
                <div className="loading">Loading&#8230;</div>
            )
        else {
            var start = this.state.start + 1;
            var last = this.state.start + 20;
            if(last > this.state.usersCount)
                last = this.state.usersCount;
            return(
                <div className="table-responsive" style={{marginTop:"50px"}}>    
                    <div className="col-md-4" style={{marginTop:"20px"}}>
                        Showing {start} to {last} of {this.state.usersCount} users...
                    </div>
                    <center className="col-md-4" style={{marginTop:"15px", marginBottom:"5px"}}>
                        <input type="text" placeholder="Search Users..." ref="search" value={this.state.searchstring} onChange={this.handleChange.bind(this,'searchstring')} className="input-lg" style={{marginRight:"10px", width:"250px", height:"30px", paddingLeft:"0px", paddingRight:"0px", paddingTop:"0px", paddingBottom:"0px"}} />
                        <input type="button" className="btn-primary" value="Search" onClick={this.searchUser.bind(this)} />
                    </center>
                    <div className="col-md-4">
                        <div className="pull-right " style={{marginTop:"15px"}}>
                            <input type="button" className="btn-success  " id="first" value="First" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'first')} />
                            <input type="button" className="btn-success" id="previous" value="Previous" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'previous')} />
                            <input type="button" className="btn-success" id="next" value="Next" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'next')} />
                            <input type="button" className="btn-success" id="last" value="Last" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'last')} />
                        </div>
                    </div>
                            
                            
                    <table className="table" id="datatable">
                        <thead>
                            <tr>
                                <th>Profile Pic</th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'name')} style={{cursor:"pointer", color:"blue"}}>Name
                                        <span id="nameasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="namedsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'username')} style={{cursor:"pointer", color:"blue"}}>Username
                                        <span id="usernameasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{ fontSize: "75%"}}></span>
                                        <span id="usernamedsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{ fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'age')} style={{cursor:"pointer", color:"blue"}}>Age
                                        <span id="ageasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="agedsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>Gender</th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'followersCount')} style={{cursor:"pointer", color:"blue"}}>Followers
                                        <span id="followersCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="followersCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'followingCount')} style={{cursor:"pointer", color:"blue"}}>Following
                                        <span id="followingCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="followingCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'tweakcount')} style={{cursor:"pointer", color:"blue"}}>Created
                                        <span id="tweakcountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="tweakcountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'viewsCount')} style={{cursor:"pointer", color:"blue"}}>Views
                                        <span id="viewsCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="viewsCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'likesCount')} style={{cursor:"pointer", color:"blue"}}>Heart
                                        <span id="likesCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="likesCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'bombedCount')} style={{cursor:"pointer", color:"blue"}}>Bombs
                                        <span id="bombedCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="bombedCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'flaggedcount')} style={{cursor:"pointer", color:"blue"}}>Flagged
                                        <span id="flaggedcountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="flaggedcountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'lastlogin')} style={{cursor:"pointer", color:"blue"}}>Last Login
                                        <span id="lastloginasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="lastlogindsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>                
                                </th>
                                <th>Login Type</th>
                                <th>Status</th>
                                <th>Popular</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.users.map((user,key) =>{

                                var created = new Date((user.lastlogin)?(user.lastlogin):(user.created));
                                var month = (created.getMonth() + 1).toString();
                                month = month.length > 1 ? month : '0' + month;
                                var day = created.getDate().toString();
                                day = day.length > 1 ? day : '0' + day;
                                var date = month + "/" + day + "/" + created.getFullYear().toString();
                                
                                var name = user.name;
                                if(name!=null && name!= "") {
                                    name = name.replace(/&quot;/g,'"');
                                    name = name.replace(/\$bkslash\$/g,'\\');
                                }
                             
                                var status;
                                if(user.status == 1)
                                    status = "Active";
                                else if(user.status == 2)
                                    status = "Suspended";
                                else
                                    status = "Banned";

                                var statusedit = user._id+"statusedit";
                                var popularedit = user._id+"popularedit";
                
                                var statusstatic = user._id+"statusstatic";
                                var popularstatic = user._id+"popularstatic";
                
                                var editbutton = user._id+"editbutton";
                
                                var selectstatus = user._id+"selectstatus";
                                var selectpopular = user._id+"selectpopular";
                             
                                var gender = "";
                                if(user.gender == "Male" || user.gender == "male")
                                    gender = "Male";
                                else if(user.gender == "Female" || user.gender == "female")
                                    gender = "Female";
                            
                                return  <tr key={key} id={user._id}>      
                                    <td><Avatar src={(user.profilepic)?(user.profilepic):('images/user_profile_pic.png')} /></td>
                                    <td>{name}</td>
                                    <td>{user.username}</td>
                                    <td>{(user.age=="(null)")?null:user.age}</td>
                                    <td>{gender}</td>
                                    <td>{user.followersCount}</td>
                                    <td>{user.followingCount}</td>
                                    <td>{user.tweakcount}</td>
                                    <td>{user.viewsCount}</td>
                                    <td>{user.likesCount}</td>
                                    <td>{user.bombedCount}</td>
                                    <td>
                                        <span onClick={this.flaggedTweaks.bind(this, user)} style={{cursor:"pointer", color:"blue"}}>                                                
                                            {user.flaggedcount}
                                        </span>
                                    </td>
                                    <td>{date}</td>
                                    <td>{user.logintype}</td>
                                    <td id={statusstatic} className="statictd">{status}</td>
                                    <td id={statusedit} className="editabletd" style={{display: "none"}}>
                                        <select id={selectstatus}>
                                          <option value='1'>Active</option>
                                          <option value='2'>Suspended</option>
                                          <option value='3'>Banned</option>
                                        </select>    
                                    </td>
                                    <td id={popularstatic} className="statictd">{(user.popular == 1)?("Yes"):("No")}</td>
                                    <td id={popularedit} className="editabletd" style={{display: "none"}}>
                                        <select id={selectpopular}>
                                          <option value='1'>Yes</option>
                                          <option value='0'>No</option>
                                        </select>
                                    </td>
                                    <td>
                                        <a id={editbutton} className="btn btn-primary editbutton" onClick={this.editUser.bind(this, user)}>Edit</a>
                                    </td>
                                    
                                </tr>
                            })}
                        </tbody>
                    </table>
                    <Dialog
                        modal={true}
                        open={this.state.open}
                        contentStyle={customContentStyle}
                        >
                        <h4>Flagged Tweaks</h4>
                        
                                <div className="pull-right" style={{marginTop:"5px"}}>
                                    <FlatButton id="close" label="Close" secondary={true} onClick={this.closeFlaggedTweaks.bind(this)} />
                                </div>
                           
                            <br/>
                       <div style={{marginTop:"20px"}}>
                            <table className="table">
                                <tbody>
                                    {(this.state.flaggedTweaks)?
                                     (
                                     this.state.flaggedTweaks.map((tweak,key) => 
                                        <tr>
                                            <td>
                                                {tweak.title}
                                            </td>
                                        </tr>

                                    )):(null)}
                                </tbody>
                           </table>
                        </div>
                    </Dialog>
                    <Dialog
                        modal={true}
                        open={this.state.openNotification}
                        contentStyle={customContentStyle}
                        >
                        <h4>Notification</h4>
                        {

                                <div className="pull-right" style={{marginTop:"5px", marginBottom:"5px"}}>
                                    <FlatButton id="close" label="Close" primary={true} onClick={this.closeDialog.bind(this)} />
                                    {
                                        (this.state.notificationLength) ?
                                        (
                                            <FlatButton id="send" label="Send" secondary={true} onClick={this.sendNotification.bind(this)} />
                                        ):
                                        (
                                            <FlatButton id="send" label="Send" disabled={true} />
                                        )
                                    }
                                 </div>
                        }
                            <br/>
                       <div style={{marginTop:"20px"}}>
                            <input type="text" className="form-control" ref="notification" onChange={this.notificationChange.bind(this)} placeholder="Enter Notification text..." />
                        </div>
                        <div style={{marginTop: "10px"}}></div>
                    </Dialog>
                </div>
            )

        }
    }
}


export default Users;

