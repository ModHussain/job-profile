import React from 'react';
import Dialog from 'material-ui/lib/dialog';
import FlatButton from 'material-ui/lib/flat-button';
import _ from 'underscore';

import mainurl from '../../public/js/url.js';

const customContentStyle = {
    width: '100%',
    maxWidth: '550px',
    overflowX: 'scroll',
    height: '100%',
    maxHeight: '1000px'
};

class Categories extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            categories:[],
            loading: true,
            categorynameLength: 0,
            open: false
        };
    }
    
    componentWillMount()
    {
        this.getAllCategories();
    }
    
    getAllCategories()
    { 
        this.setState({loading: true});
        
        var data = "{categories{_id,categoryname}}";
        $.ajax
        ({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data ,
            dataType : 'json',
            success:(data) => {
            //    console.log(JSON.stringify(data));
                this.setState({categories:data.data.categories, loading: false});
            },
            error:(err) => {
                console.log(JSON.stringify(err));
            }
        });
    }
  
    editCategory(category, e) {
        if($('#'+category._id+"editbutton").html() == "Edit") {
            $("#"+category._id+"editabletextfield").val(category.categoryname);
            $('#'+category._id+"staticname").hide();
            $('#'+category._id+"editablename").show();
            $("#"+category._id+"editabletextfield").focus();
            $('#'+category._id+"editbutton").html('Save');
        }
        else {
            $('#'+category._id+"staticname").show();
            $('#'+category._id+"editablename").hide();
            console.log($("#"+category._id+"editabletextfield").val());
            $('#'+category._id+"editbutton").html('Edit');
            this.editCategoryName(category, $("#"+category._id+"editabletextfield").val());
        }
    }
    
    editCategoryName(category, categoryname)
    {   
        if (categoryname.trim() == "") {
            this.alert('Category should not be empty.');
        }    
        else {
            var data = "mutation M{editCategory(_id:\""+category._id+"\",categoryname:\""+categoryname.trim()+"\"){_id,categoryname}}";
            $.ajax
            ({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data ,
                dataType : 'json',
                success:(data) => {
                //    console.log(JSON.stringify(data));
                    var categories = this.state.categories;
                    categories.map((categoryRecord, key) =>{
                        if(categoryRecord._id == category._id)
                        {
                            categories[key].categoryname = data.data.editCategory.categoryname;
                            this.setState({users:users});
                        }
                    });
                },
                error:(err) => {
                    alert(JSON.stringify(err));
                }
            });
        }
    }
    
    alert(message) {
        $.alert(message, {
                closeTime: 5000,
                autoClose: true,
                position: ['top-right', [57, 0]],                
                type: 'danger'
            });
    }

    deleteCategory(category, e) {
        console.log(category.categoryname);
    }
    
    openDialog() {
        this.setState({open: true},() => {
            this.refs.categoryname.focus();
        });
    }
    
    closeDialog() {
        this.setState({open: false});
    }
    
    categoryChange() {
        this.setState({categorynameLength: this.refs.categoryname.value.length})
    }
    
    addCategory() {
        if (this.refs.categoryname.value.trim() == "") {
            this.refs.categoryname.value = "";
            this.alert('Category should not be empty.');
        }    
        else {
            this.closeDialog();
            var data = "mutation M{addCategory(categoryname:\"" + this.refs.categoryname.value.trim() + "\"){_id,categoryname}}";
            $.ajax
            ({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data ,
                dataType : 'json',
                success:(data) => {
                    this.getAllCategories();
                },
                error:(err) => {
                    alert(JSON.stringify(err));
                }
            });
        }
    }
    
    render()
    {   
        if(this.state.loading) 
            return (
                <div className="loading">Loading&#8230;</div>
            )
        else {
            return(
                <div className="container">
                    <div className="col-md-2"></div>
                    <div className="col-md-8">
                        <div className="table-responsive" style={{marginTop:"50px"}}>    
                            <div className="pull-right" style={{marginTop:"10px"}}>
                                <a className="btn btn-success" onClick={this.openDialog.bind(this)}>Add Category</a>
                            </div>
                            <table className="table" id="datatable">
                                <thead>
                                    <tr>
                                        <th>Category Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.categories.map((category,key) =>{
                                        var staticname = category._id+"staticname";
                                        var editablename = category._id+"editablename";
                
                                        var editbutton = category._id+"editbutton";
                                        var savebutton = category._id+"savebutton";
                                        
                                        var editabletextfield = category._id+"editabletextfield";
                
                                        return  <tr key={key} id={category._id}>      

                                            <td id={staticname}>
                                                <span>{category.categoryname}</span>
                                            </td>
                                            <td id={editablename} style={{display: "none"}}>
                                                <input id={editabletextfield} type="text" />
                                            </td>
                                            <td >
                                                <a id={editbutton} className="btn btn-primary editbutton" onClick={this.editCategory.bind(this, category)}>Edit</a>
                                            </td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="col-md-2"></div>
                    <Dialog
                        modal={true}
                        open={this.state.open}
                        contentStyle={customContentStyle}
                        >
                        <h4>Add Category</h4>
                        {

                                <div className="pull-right" style={{marginTop:"5px", marginBottom:"5px"}}>
                                    <FlatButton id="close" label="Close" primary={true} onClick={this.closeDialog.bind(this)} />
                                    {
                                        (this.state.categorynameLength) ?
                                        (
                                            <FlatButton id="add" label="Add" secondary={true} onClick={this.addCategory.bind(this)} />
                                        ):
                                        (
                                            <FlatButton id="add" label="Add" disabled={true} />
                                        )
                                    }
                                 </div>
                        }
                            <br/>
                       <div style={{marginTop:"20px"}}>
                            <input type="text" className="form-control" ref="categoryname" onChange={this.categoryChange.bind(this)} placeholder="Enter Category name..." />
                        </div>
                        <div style={{marginTop: "10px"}}></div>
                    </Dialog>
                </div>
            )
        }
    }
}


export default Categories;