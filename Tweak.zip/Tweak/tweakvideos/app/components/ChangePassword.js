import React from 'react';
import mainurl from '../../public/js/url.js'; 

class ChangePassword extends React.Component
{

	constructor(props) {
		super(props)
   		this.state = {
				"id": this.props.params.id,
	            "pwd": '',
	            "repwd": '',
	            "route": false
        	};
	}

    handelSubmit (){

        if(this.state.pwd==this.state.repwd && this.state.pwd.length>3) {
        	
            var id = this.state.id;
            var pwd = this.state.pwd;
            var data="mutation M{changePassword(_id:\""+id+"\",password:\""+pwd+"\"){_id,name,username,email,password}}"
            var success="";
            $.ajax({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data,
                success: function(msg){
                    console.log(JSON.stringify(msg));
                    alert("Password changed Successfully.");
                    this.setState({"route": true});
                }.bind(this)
            })
        }
        else if(this.state.pwd!=this.state.repwd){
            alert("Password and Re-type Password should be same.");
            this.setState({"pwd":""});
            this.setState({"repwd":""});
        }
        else {
            alert("Password should contain minimum 4 charecters.");
            this.setState({"pwd":""});
            this.setState({"repwd":""});
        }
    }

    handleChange(type,e) {
        var change = {};
        change[type] = e.target.value;
        this.setState(change);
    }

    cancel() {
        this.setState({"pwd":""});
        this.setState({"repwd":""});
    }

    render()
    {
        var center={
           textAlign:"center"
        }
        var style={
            marginTop: 10
        }

        if(this.state.route == false) {
            return(
                <div className="form-horizontal">
                    <div className="container">

                        <div className="row"  style={style}>
                            <div className="col-sm-12">
                                <h1  style={center}>Reset your Tweak Password here..</h1>
                            </div>     
                        </div>

                        <div className="row"  style={style}>
                            <label className="control-label col-sm-5">Password: </label>
                            <div className="col-sm-7">
                                <input type="password" name="pwd" ref="pwd" value={this.state.pwd} onChange={this.handleChange.bind(this,'pwd')} />
                            </div> 
                        </div>

                        <div className="row"  style={style}>
                            <label className="control-label col-sm-5">Re-type Password: </label>
                            <div className="col-sm-7">
                                <input type="password" name="repwd" ref="repwd" value={this.state.repwd} onChange={this.handleChange.bind(this,'repwd')} />
                            </div> 
                        </div>

                        <div className="row"  style={style}>
                            <div className=" col-sm-5"></div>
                            <div className=" col-sm-1">
                                <input type="button" name="submit" value="Submit" onClick={this.handelSubmit.bind(this)} />
                            </div>
                            <div className="col-sm-1">
                                <input type="button" name="cancel" value="Cancel" onClick={this.cancel.bind(this)} />
                            </div> 
                            <div className=" col-sm-5"></div>
                        </div>
                    </div>
                </div>
            )
        }
        else {
            return(
                <div className="form-horizontal">
                    <div className="container" style={center}>
                        <h1>Thank you for changing password..!</h1>
                    </div>
                </div>
            )
        }
    }

}
//change password
export default ChangePassword;