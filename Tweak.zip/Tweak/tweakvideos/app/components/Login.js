import React from 'react';
import TextField from 'material-ui/lib/text-field';
import Paper from 'material-ui/lib/paper';
import RaisedButton from 'material-ui/lib/raised-button';
import { PropTypes } from 'react-router'

class Login extends React.Component
{
    constructor(props)
  {
    super(props)
   this.state = {username:'',
                 password:'',
                 usernameerror:'',
                 passworderror:'' };
  }  

_handleFloatingInputChange(type,e)
{  
  var change = {};
  change[type] = e.target.value;
  this.setState(change);
}

handleSubmit()
{  
  this.setState({usernameerror:'',passworderror:''});
     if(!this.state.username && !this.state.password)
      this.setState({usernameerror:'This field is required',passworderror:'This field is require'});
     else if(!this.state.username )
      this.setState({usernameerror:'This field is required'});
     else if(!this.state.password)
      this.setState({passworderror:'This field is required'});
     else
      {
        if(this.state.username == "admin" && this.state.password == "tweak123")
        {
         sessionStorage.setItem('user', 'admin');
   //      this.context.history.pushState(null, '/users');
            window.location.href = '/#/users';
        }
        else
         this.setState({usernameerror:'Invalid Username',passworderror:'Invalid Password'});
      }
}
  render()
  {   

      return(
        <div className="row-fluid">



         <form className="form-horizontal" style={{paddingTop:"63px"}}>
<fieldset>

<div className="col-md-6 col-md-offset-3">
<Paper zDepth={3}>
<legend style={{textAlign:"center",fontWeight:"bold",fontSize:"23px",paddingTop:"13px",paddingBottom:"13px"}}>Login</legend>
<div className="form-group">
  <div className="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1">
  <TextField hintText="Enter Username" floatingLabelText="Username" errorText={this.state.usernameerror} value={this.state.username} onChange={this._handleFloatingInputChange.bind(this,'username')} type="text" fullWidth={true} />
    
  </div>
</div>

<div className="form-group">
  <div className="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1">
    <TextField hintText="Enter Password" floatingLabelText="Password"  errorText={this.state.passworderror} value={this.state.password} onChange={this._handleFloatingInputChange.bind(this,'password')} type="password" fullWidth={true}/>
    
  </div>
</div>

<div className="form-group">
  <div className="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1" style={{paddingBottom:"23px"}}>
     <RaisedButton label="Login" secondary={true} onClick={this.handleSubmit.bind(this)}/>
  </div>
</div>
</Paper>
</div>
</fieldset>
</form>

 

  
        </div>
        )
       }
  
  }

  Login.contextTypes = { history: PropTypes.history }
  
export default Login;