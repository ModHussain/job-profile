import React from 'react';
import TextField from 'material-ui/lib/text-field';
import Paper from 'material-ui/lib/paper';
import RaisedButton from 'material-ui/lib/raised-button';

import mainurl from '../../public/js/url.js';

class Alert extends React.Component
{  
    constructor(props)
  {
    super(props)
   this.state = {alertmessage:'',messageerror:''};
  }

  _handleInputChange(e)
{  
  //alert(e.target.value);
  this.setState({alertmessage:e.target.value});

}

 handleSubmit()
 {
    this.setState({alertmessage:''});
    if(!this.state.alertmessage)
      this.setState({messageerror:'This field is required'});
     else
      {
        var data = "{adminNotification(notification:\""+this.state.alertmessage+"\"){message}}";
        $.ajax({
        type: "POST",
        url: mainurl,
        contentType: "application/graphql",
        data: data ,
        dataType : 'json',
        success:(data) => {
           //alert(JSON.stringify(data));
           alert("Message sent successfully");
        },
        error:(err) => {
            console.log(JSON.stringify(err));
          }
        });
      }
 }

  render()
  {   

      return(
      <div className="row-fluid">



         <form className="form-horizontal" style={{paddingTop:"63px"}}>
<fieldset>

<div className="col-md-6 col-md-offset-3">
<Paper zDepth={3} >
<legend style={{textAlign:"center",fontWeight:"bold",fontSize:"23px",paddingTop:"13px",paddingBottom:"13px"}}>Enter Alert Text</legend>
<div className="form-group">
  <div className="col-md-10 col-md-offset-1">
  <TextField floatingLabelText="Enter Alert Message" errorText={this.state.messageerror} value={this.state.alertmessage} onChange={this._handleInputChange.bind(this)}  fullWidth={true} multiLine={true} rows={5}/>
    
  </div>
</div>

<div className="form-group">
  <div className="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1" style={{paddingBottom:"23px"}}>
     <RaisedButton label="send" secondary={true} onTouchTap={this.handleSubmit.bind(this)}/>
  </div>
</div>
</Paper>
</div>
</fieldset>
</form>
        </div>
            )
  }
  
  }

  
export default Alert;