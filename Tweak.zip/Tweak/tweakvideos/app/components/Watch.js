import React from 'react';
import mainurl from '../../public/js/url.js'; 
import { default as Video, Controls, Play, Mute, Seek, Time, Overlay } from 'react-html5video';
import YouTube from 'react-youtube';

class Watch extends React.Component
{

	constructor(props) {
		super(props)
   		this.state = {
				"id": this.props.params.id,
                "title": '',
	            "amazon": '',
                "youtube": '',
                "link": '',
                "route": false,
                "tweak": {}
        	};
	}

    componentWillMount() {
		var id = this.state.id;
        var data = "{tweak(_id:\""+id+"\"){title,image,videourl,starttime,endtime,tweakurl,tweakimage}}"
        console.log(data)
        var success="";
        $.ajax({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data,
            success: function(msg){
                    console.log(JSON.stringify(msg));
                    this.setState({"tweak": msg.data.tweak});
                    this.setState({"route": true});
                }.bind(this)
            }
        )

        var data1 = "mutation M{updateTweak(_id:\""+this.state.id+"\",userid:\"Share page\",categoryType:\"view\",){_id}}";
        console.log(data1);
        var success="";
        $.ajax({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data1,
            success: function(msg){ 
                console.log("msg: "+JSON.stringify(msg));
            }
        })
	}

    onEnd(e) {
        e.target.seekTo(this.state.tweak.starttime);
    }

    render()
    {

        var center={
           textAlign:"center"
        }
        var style={
            marginTop: 10
        }
        if(!this.state.tweak) {
            return(
                    <div>
                        Tweak does not exist...
                    </div>
                )
        }
        else {
            if(this.state.route == false) {
                return(
                    <div>
                        Loading...
                    </div>
                )
            }
            else {

                    var n = this.state.tweak.videourl.indexOf("=");
                    var youtubeid = this.state.tweak.videourl.slice(n+1);

                    const opts = {
                                height: '310',
                                width: '100%', 
                                playerVars: { // https://developers.google.com/youtube/player_parameters
                                    controls: 0,
                                    autoplay: 1,
                                    start: this.state.tweak.starttime,
                                    end: this.state.tweak.endtime
                                }
                            };

            	    return(
                        <div className="container">

                            <div className="row"  style={{paddingTop:"10px"}}>
                                <div className="col-sm-12">
                                    <center>
                                        <h3  style={{color:"blue"}}>{this.state.tweak.title}</h3>
                                    </center>
                                </div>     
                            </div>

                            <div className="row" style={{paddingTop:"10px"}} >
                            <div className="col-md-3"></div>
                            <div className="col-md-6">
                                <center>    
                                    {
                                        (this.state.tweak.tweakurl) ? ( 
                                            <Video controls autoPlay id="v" style={{ width:"100%", height:"310px"}}>
                                                <source src={this.state.tweak.tweakurl} type="video/mp4" />
                                                 <Overlay />
                                                 <Controls>
                                                    <Play />
                                                    <Seek />
                                                    <Time />
                                                    <Mute />
                                                </Controls>
                                            </Video>
                                        ) : 
                                        (
                                            <YouTube
                                                videoId = {youtubeid}
                                                opts = {opts} 
                                                onEnd = {this.onEnd.bind(this)} />
                                        )
                                    }
                                </center>
                                </div>
                                <div className="col-md-3"></div>
                            </div>

                            <div className="row" style={{paddingTop:"20px"}}>
                                <div className="col-sm-3"></div>
                                <div className="col-sm-6">
                                    <center>
                                        <a href="https://itunes.apple.com/us/app/bloop-it/id635655594?mt=8" style={{paddingRight:"25px"}} >
                                                <img src="images/appstore.png" style={{width:"30%"}} />
                                        </a>
                                        <a href="https://play.google.com/store/apps/details?id=com.bloopit.activity&hl=en" >
                                            <img src="images/google_play.png" style={{width:"30%"}} />
                                        </a>
                                    </center>
                                </div>
                            </div>

                            <div className="row" style={{paddingTop:"15px"}}>
                                <div className="col-sm-3"></div>
                                <div className="col-sm-6">
                                    <center>
                                        <a href={this.state.link}  style={{paddingRight:"25px"}} >
                                            <img src="images/youtube.png" style={{width:"30%"}} />
                                        </a>
                                        <a href="http://bloopit.com/" >
                                            <img src="images/tweak_btn.png" style={{width:"30%"}} />
                                        </a>
                                    </center>
                                </div>
                            </div>

                        </div>
            	    )
              } 
        }

    }
}

export default Watch;


//width="540" height="310" style={{width:"100%", maxWidth:"560px"}}