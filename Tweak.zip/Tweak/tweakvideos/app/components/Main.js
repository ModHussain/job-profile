import React from 'react';
import Header from './Header.js';
import { PropTypes } from 'react-router';

class Main extends React.Component
{
    constructor(props)
    {
        super(props);
    }
        
    render()
    {
        var path = this.props.location.pathname.substring(1,6);
        return  <div className="main-container">
                { 
                    (path == "reset" || path == "watch") ? 
                    (null) :
                    (
                        <Header path={this.props.location.pathname}/>
                    )
                }
            <div className="container-fluid">
                {this.props.children}
            </div>
        </div>
    }
}

Main.contextTypes = { history: PropTypes.history }

export default Main;