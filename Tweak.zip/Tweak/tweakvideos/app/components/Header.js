import React from 'react';

import { PropTypes } from 'react-router';

class Header extends React.Component
{

    logout(e)
    {
        sessionStorage.removeItem('user');
        window.location.href = '/';
    }
    
    componentDidMount() {
        var res = window.location.href.split("/");
        var result = res[4].split("?");
        $(".links").removeClass("active");
        $("#"+result[0]).addClass("active");
    }
    
    route(value, e) {
        e.preventDefault();
    //    $(".links").removeClass("active");
    //    $("#"+value).addClass("active");
        var res = window.location.href.split("/");
        var result = res[4].split("?");
        console.log(result)
        if(result[0] == value)
            window.location.reload(false); 
        else
            window.location.href = '/#/'+value;
    }
    
    render()
    {
        $("#users").addClass("active");
        var res = window.location.href.split("/");
        var result = res[4].split("?");
        $(".links").removeClass("active");
        $("#"+result[0]).addClass("active");
        return  (
            
            <nav className="navbar navbar-default navbar-fixed-top" style={{backgroundColor:"lightgray"}}>
                {
                    (result[0] == "")?
                    (
            <div className="container-fluid center-nav">
                                <ul className="nav  nav-center">
                                    <li><a className="navbar-brand" href="#" style={{paddingTop:"0px"}}><img src="images/logo.jpg" /></a></li>
                                </ul>
                        </div>
                    ):
                    (<div className="container-fluid">
                                <div className="navbar-header">
                                    <a className="navbar-brand" onClick={this.route.bind(this, 'users')} style={{paddingTop:"0px"}}><img src="images/logo.jpg" /></a>
                                </div>
                                <ul className="nav navbar-nav">
                                    <li className="links active" id="users"><a onClick={this.route.bind(this, 'users')} style={{cursor:"pointer"}}>Users</a></li>
                                    <li className="links" id="tweaks"><a onClick={this.route.bind(this, 'tweaks')} style={{cursor:"pointer"}}>Tweaks</a></li>
                                    <li className="links" id="categories"><a onClick={this.route.bind(this, 'categories')} style={{cursor:"pointer"}}>Categories</a></li> 
                                    <li className="links" id="alert"><a onClick={this.route.bind(this, 'alert')} style={{cursor:"pointer"}}>Notifications</a></li> 
                                </ul>
                                <ul className="nav navbar-nav pull-right">
                                    <li><a onClick={this.logout.bind(this)} style={{cursor:"pointer"}}>Sign out</a></li>
                                </ul>
                            </div>
                        
                    )
                }
            </nav>
            
        )
    }
}



export default Header;