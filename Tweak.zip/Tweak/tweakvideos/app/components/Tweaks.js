import React from 'react';
import Dialog from 'material-ui/lib/dialog';
import FlatButton from 'material-ui/lib/flat-button';
import CheckboxGroup from 'react-checkbox-group';
import _ from 'underscore';

import mainurl from '../../public/js/url.js';

const customContentStyleEdit = {
    width: '100%',
    maxWidth: '550px',
    overflowX: 'scroll',
    height: '100%',
    maxHeight: '1000px'
};


const customContentStyleCategory = {
    width: '100%',
    maxWidth: '750px',
    overflowX: 'scroll',
    height: '100%',
    maxHeight: '1000px'
};

class Tweaks extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            tweaks:[],
            tweaksBackUp:[],
            loading: true,
            categories:[],
            openEdit: false,
            openCategories: false,
            tweak: {},
            title: '',
            selectedCategorieNames: '',
            selectedCategories: [],
            page: 0,
            displayingTweaks: []
        };
    }

    componentWillMount()
    {
        this.getAllCategories();
        this.getAllTweaks();
        var clipboard = new Clipboard('.share');

        clipboard.on('success', function(e) {
            console.info('Action:', e.action);
            console.info('Text:', e.text);
            console.info('Trigger:', e.trigger);

            e.clearSelection();
        });

        clipboard.on('error', function(e) {
            console.error('Action:', e.action);
            console.error('Trigger:', e.trigger);
        });
    }


    getAllTweaks()
    {
        this.setState({loading: true});
        var data = "{tweaks{_id,username,title,description,image,videourl,starttime,endtime,tweakurl,tweakimage,status,publicScope,nsfw,category{categoryid},viewsCount,likes,bombed,created,status,staffpick,publicScope,tags{tagName},shareurl}}";
        $.ajax
        ({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data ,
            dataType : 'json',
            success:(data) => {
            //    console.log(JSON.stringify(data));
                var array = data.data.tweaks;
                var slicedArray = array.slice(0,20);
                
                this.setState({displayingTweaks:slicedArray, tweaks:data.data.tweaks, page:1, loading: false});
                var array = data.data.tweaks;
                array.map((user,key)=>{
                    array[key].likesCount = array[key].likes.length;
                    array[key].bombedCount = array[key].bombed.length;
                 //   console.log(array[key].created);
                });
                this.setState({tweaksBackUp: array});
            },
            error:(err) => {
                console.log(JSON.stringify(err));
            }
        });
    }
    
    getAllCategories()
    {
        var data = "{categories{_id,categoryname}}";
        $.ajax
        ({
            type: "POST",
            url: mainurl,
            contentType: "application/graphql",
            data: data ,
            dataType : 'json',
            success:(data) => {
           //     console.log(JSON.stringify(data));
                this.setState({categories:data.data.categories});
            },
            error:(err) => {
                console.log(JSON.stringify(err));
            }
        });
    }

    deleteTweak(tweak, e) {
        if (confirm('Are you sure you want to delete this record?')) {
            var _id = tweak._id;
            var data = "mutation M{removeTweakAdmin(tweakid:\""+_id+"\"){_id,message}}";
       //     console.log(data);
            $.ajax
            ({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data ,
                dataType : 'json',
                success:(data) => {
                    console.log(JSON.stringify(data));
                    var displayingTweaks = this.state.displayingTweaks;
                    this.state.displayingTweaks.map((tweak,key) =>{
                        if(tweak._id == _id)
                        {
                            displayingTweaks.splice(key, 1);
                            this.setState({displayingTweaks:displayingTweaks});
                        }
                    });
                    
                    var tweaks = this.state.tweaks;
                    this.state.tweaks.map((tweak,key) =>{
                        if(tweak._id == _id)
                        {
                            tweaks.splice(key, 1);
                            this.setState({tweaks:tweaks});
                        }
                    });
                    
                    var tweaksBackUp = this.state.tweaksBackUp;
                    this.state.tweaksBackUp.map((tweak,key) =>{
                        if(tweak._id == _id)
                        {
                            tweaksBackUp.splice(key, 1);
                            this.setState({tweaksBackUp:tweaksBackUp});
                            var page = this.state.page
                        }
                    });
                },
                error:(err) => {
                    console.log(JSON.stringify(err));
                }
            });
        }
    }
    
    openEdit(tweak, e) {
        var categoryArray=[];
        tweak.category.map((cat,key)=>{
            categoryArray.push(cat.categoryid);
        })
        this.setState({selectedCategories:categoryArray});
        
        this.setState({title: tweak.title});
        this.setState({tweak: tweak});
        this.setState({openEdit: true},()=>{
            $("#selectstatus").val(tweak.status);
            $("#selectpicks").val(tweak.staffpick);
        }); 

        var categories = "";
        tweak.category.map((categoryid,key)=>{
            this.state.categories.map((category,key)=>{
                if(categoryid.categoryid == category._id)
                    categories = categories + ", " + category.categoryname;
            })
        })
        
        categories = categories.substring(2);
        this.setState({selectedCategorieNames:categories});
        
    }

    closeEdit() {
        this.setState({openEdit: false});
    }
    
    updateTweak() { 
        
        if(this.state.title.trim()=="") 
            this.alert('Tweak Title should not be empty.');
        
        else if(this.state.selectedCategories=="")
            this.alert('Minimum one Category should be selected.');
        
        else {    
            this.setState({openEdit: false});

            var status = $("#selectstatus").val();
            var picks = $("#selectpicks").val();
            var _id = this.state.tweak._id;
            var title = this.state.title;
            title = title.replace(/"/g,'&quot;');
            title = title.replace(/\\/g,'\$bkslash\$');

            var category="[";
            this.state.selectedCategories.map((cat,key) => {
                category=category+"{categoryid: \""+cat+"\"},";
            })
            category=category + "]";

            var data = "mutation M{updateTweakAdmin(_id:\""+_id+"\", title: \""+title+"\"category:"+category+", status:"+status+", staffpick: "+picks+",){_id,message,title,category{categoryid},status,staffpick}}";
            console.log(data);
            $.ajax
            ({
                type: "POST",
                url: mainurl,
                contentType: "application/graphql",
                data: data ,
                dataType : 'json',
                success:(data) => {
                    console.log(JSON.stringify(data));
                    var tweaks = this.state.tweaks;
                    this.state.tweaks.map((tweak,key) =>{
                        if(tweak._id == _id)
                        {
                            tweaks[key].title = data.data.updateTweakAdmin.title;
                            tweaks[key].staffpick = data.data.updateTweakAdmin.staffpick;
                            tweaks[key].status = data.data.updateTweakAdmin.status;
                            tweaks[key].category = data.data.updateTweakAdmin.category;
                            this.setState({tweaks:tweaks}); 
                        }
                    });
                    var tweaksBackUp = this.state.tweaksBackUp;
                    this.state.tweaksBackUp.map((tweak,key) =>{
                        if(tweak._id == _id)
                        {
                            tweaksBackUp[key].title = data.data.updateTweakAdmin.title;
                            tweaksBackUp[key].staffpick = data.data.updateTweakAdmin.staffpick;
                            tweaksBackUp[key].status = data.data.updateTweakAdmin.status;
                            tweaksBackUp[key].category = data.data.updateTweakAdmin.category;
                            this.setState({tweaksBackUp:tweaksBackUp});
                        }
                    });
                },
                error:(err) => {
                    console.log(JSON.stringify(err));
                }
            });
        }
    }
    
    alert(message) {
        $.alert(message, {
                closeTime: 5000,
                autoClose: true,
                position: ['top-right', [-0.42, 0]],                
                type: 'danger'
            });
    }

    handleChange(type,e) {
        var change = {};
        change[type] = e.target.value;
        if(type=="title")
        {
            var len=this.state.title.length;
            console.log(42-len)
            len= 42-len;
            $('#textLimit').text(": "+len);
        }
        this.setState(change)
    }
    
    openCategory() {
        

        this.setState({openCategories: true}); 
    }

    closeCategory() {
        this.setState({openCategories: false});
    }
    
    clearCategory() {
        $('.check').attr('checked', false);
        $('.check').attr('disabled', false);
        this.setState({selectedCategories:''});
    }
    
    doneCategory() {
        this.setState({openCategories: false});
        var array = [];
        this.state.selectedCategories.map((id,key) => {
            this.state.categories.map((category,key) => {
                if(id == category._id) {
                    array = array + ", " + category.categoryname;
                }
            })
            
        });
        
        array = array.substring(2);
        this.setState({selectedCategorieNames: array});
    }
    
    handleCategory(e) {
        console.log(this.refs.categoryGroup.getCheckedValues())
        if(this.refs.categoryGroup.getCheckedValues().length == 4)
            $('#'+e.target.id).attr('checked', false);
        if(this.refs.categoryGroup.getCheckedValues().length >= 3){
            $('.check').attr('disabled', true);
            this.refs.categoryGroup.getCheckedValues().map((id,key) => {
                $('#'+id).attr('disabled', false);
            })
        }
        else
            $('.check').attr('disabled', false);
        this.setState({selectedCategories:this.refs.categoryGroup.getCheckedValues()});
    }
    
    
    searchTweak() {
        var search = this.refs.search.value.toLowerCase();
        if(this.refs.search.value=="")
        {
            var array = this.state.tweaksBackUp;
            this.setState({tweaks: array, displayingTweaks: array.slice(0,20), page:1});
        }
        else {
            var searchResult=[];
            this.state.tweaksBackUp.map((tweak,key)=>{
                if(tweak.title.toLowerCase().indexOf(search) != -1)
                    searchResult.push(tweak);
                tweak.tags.map((tag,key)=>{
                    if(tag.tagName.toLowerCase().indexOf(search) != -1)
                        searchResult.push(tweak);
                })
            })
            
            var uniquetweaks = [];
           searchResult.map((tweak,key)=>{
                if($.inArray(tweak, uniquetweaks) === -1) uniquetweaks.push(tweak);
            });
            
            this.setState({tweaks:uniquetweaks, displayingTweaks: uniquetweaks.slice(0,20), page:1});
        }
        $('.sort').hide();
    }
    
    shareUrl(tweak) {
        console.log(tweak.shareurl);
        var Copied = tweak.shareurl.createTextRange();
        Copied.execCommand("Copy");
    }
    
    pagination(val, e) {
        console.log(val);
        var page = this.state.page;
        var pages = Math.ceil(this.state.tweaks.length/20);
        if(val == 'first')
            this.setState({displayingTweaks: this.state.tweaks.slice(0,20), page:1});
        else if(val == 'previous') {
            if(page != 1)
                this.setState({displayingTweaks: this.state.tweaks.slice(20*(page-2),20*(page-1)), page:page-1});
        }
        else if(val == 'next') {
            if(pages > page)
                this.setState({displayingTweaks: this.state.tweaks.slice(20*page,20*(page+1)), page:page+1});
        }
        else if(val == 'last') {
            if(page != pages)
                this.setState({displayingTweaks: this.state.tweaks.slice(20*(pages-1),20*(pages)), page:pages});
        }
    } 
    
    sorting(val, e) {
        console.log(val);
        var array = [];
        var search = this.refs.search.value.toLowerCase();
        if(this.refs.search.value == "")
            array = this.state.tweaksBackUp;
        else {
            var searchResult = [];
            this.state.tweaksBackUp.map((tweak,key)=>{
                if(tweak.title.toLowerCase().indexOf(search) != -1)
                    searchResult.push(tweak);
                tweak.tags.map((tag,key)=>{
                    if(tag.tagName.toLowerCase().indexOf(search) != -1)
                        searchResult.push(tweak);
                })
            })

           searchResult.map((tweak,key)=>{
                if($.inArray(tweak, array) === -1) array.push(tweak);
            });
        }
        var sorted = [];
        if($('#'+val+'asc').css("display") == "none") {
            $('.sort').hide();
            $('#'+val+'asc').show();
            if(val == 'title')
                sorted = _.sortBy(array, function (i) { return i.title.toLowerCase(); });
            
            else if(val == 'username')
                sorted = _.sortBy(array, function (i) { return i.username.toLowerCase(); });
            
            else if(val == 'created') {
                array.sort(function(a,b){
                    return new Date(a.created).getTime() - new Date(b.created).getTime() 
                });
                sorted = array;
            }
            else {
                sorted = _.sortBy(array, val); 
            }
            this.setState({displayingTweaks: sorted.slice(0,20), tweaks:sorted, page: 1});
        }
        else {
            $('.sort').hide();
            $('#'+val+'dsc').show();
            if(val == 'title')
                sorted = _.sortBy(array, function (i) { return i.title.toLowerCase(); });
            
            else if(val == 'username')
                sorted = _.sortBy(array, function (i) { return i.username.toLowerCase(); });
            
            else if(val == 'created') {
                array.sort(function(a,b){
                    return new Date(a.created).getTime() - new Date(b.created).getTime() 
                });
                sorted = array;
            }
            else {
                sorted = _.sortBy(array, val); 
            }
            this.setState({displayingTweaks: sorted.slice(0,20), tweaks:sorted, page: 1});
            sorted.reverse();
            this.setState({displayingTweaks: sorted.slice(0,20), tweaks:sorted, page: 1});
        }
    }
    
    render()
    {   
        if(this.state.loading) 
            return (
                <div className="loading">Loading&#8230;</div>
            )
        else {
            var pages = Math.ceil(this.state.tweaks.length/20);
            console.log("length: "+this.state.displayingTweaks.length);
             return(
                <div className="table-responsive" style={{marginTop:"50px"}}>   
                    <div className="col-md-4" style={{marginTop:"20px"}}>
                        Showing {this.state.page} of {pages} page(s)...
                    </div>
                    <center className="col-md-4" style={{marginTop:"15px", marginBottom:"5px"}}>
                        <input type="text" placeholder="Search Tweaks & Tags..." ref="search" className="input-lg" style={{marginRight:"10px", width:"250px", height:"30px", paddingLeft:"0px", paddingRight:"0px", paddingTop:"0px", paddingBottom:"0px"}} />
                        <input type="button" className="btn-primary " value="Search" onClick={this.searchTweak.bind(this)} />
                    </center>
                    <div className="col-md-4">
                        <div className="pull-right " style={{marginTop:"15px"}}>
                            <input type="button" className="btn-success  " id="first" value="First" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'first')} />
                            <input type="button" className="btn-success" id="previous" value="Previous" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'previous')} />
                            <input type="button" className="btn-success" id="next" value="Next" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'next')} />
                            <input type="button" className="btn-success" id="last" value="Last" style={{marginRight:"5px"}} onClick={this.pagination.bind(this, 'last')} />
                        </div>
                    </div>
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Video</th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'title')} style={{cursor:"pointer", color:"blue"}}>Title
                                        <span id="titleasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="titledsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>Categories</th>
                                <th>#Tags</th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'username')} style={{cursor:"pointer", color:"blue"}}>@User
                                        <span id="usernameasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="usernamedsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>    
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'viewsCount')} style={{cursor:"pointer", color:"blue"}}>Views
                                        <span id="viewsCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="viewsCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>             
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'likesCount')} style={{cursor:"pointer", color:"blue"}}>Heart
                                        <span id="likesCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="likesCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'bombedCount')} style={{cursor:"pointer", color:"blue"}}>Bombs
                                        <span id="bombedCountasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="bombedCountdsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>            
                                </th>
                                <th>
                                    <span onClick={this.sorting.bind(this, 'created')} style={{cursor:"pointer", color:"blue"}}>Date
                                        <span id="createdasc" className="glyphicon glyphicon-chevron-down sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                        <span id="createddsc" className="glyphicon glyphicon-chevron-up sort" aria-hidden="true" style={{display: "none", fontSize: "75%"}}></span>
                                    </span>
                                </th>
                                <th>Status</th>
                                <th>Picks</th>
                                <th>Privacy</th>
                            </tr>
                        </thead>

                        <tbody>
                            {this.state.displayingTweaks.map((tweak,key) =>{
                                
                                var title = tweak.title;
                                title = title.replace(/&quot;/g,'"');
                                title = title.replace(/\$bkslash\$/g,'\\');
                                

                                var created = new Date(tweak.created);
                                var month = (created.getMonth() + 1).toString();
                                month = month.length > 1 ? month : '0' + month;
                                var day = created.getDate().toString();
                                day = day.length > 1 ? day : '0' + day;
                                var date = month + "/" + day + "/" + created.getFullYear().toString();

                                var categories = "";
                                tweak.category.map((categoryid,key)=>{
                                    this.state.categories.map((category,key)=>{
                                        if(categoryid.categoryid == category._id)
                                        {
                                            categories = categories + ", " + category.categoryname;
                                        }
                                    })
                                })
                                categories = categories.substring(2);

                                var tags = "";
                                tweak.tags.map((tag,key)=>{
                                    tags = tags + ", " + tag.tagName;
                                })
                                tags = tags.substring(2);

                                var image;
                                (tweak.tweakimage)?(image=tweak.tweakimage):(image=tweak.image);

                                var statusedit = tweak._id+"statusedit";
                                var titleedit = tweak._id+"titleedit";
                
                                var statusstatic = tweak._id+"statusstatic";
                                var titlestatic = tweak._id+"titlestatic";
                
                                var inputtitle = tweak._id+"inputtitle";

                                var status;
                                if(tweak.status == 1)
                                    status = "Active";
                                else if(tweak.status == 2)
                                    status = "Suspended";

                
                                
                                return  <tr key={key} >      
                                    <td><img style={{width:"75px", height:"50px"}} src={image} /></td>
                                    <td id={titlestatic}>{title}</td>
                                    <td>{categories}</td>
                                    <td>{tags}</td>
                                    <td>{tweak.username}</td>
                                    <td>{tweak.viewsCount}</td>
                                    <td>{tweak.likes.length}</td>
                                    <td>{tweak.bombed.length}</td>
                                    <td>{date}</td>
                                    <td>{status}</td>
                                    <td>{(tweak.staffpick == 1)?("Yes"):("No")}</td>
                                    <td>{(tweak.publicScope)?("Public"):("Private")}</td>
                                    <td>
                                        <a className="btn btn-info share" data-clipboard-text={tweak.shareurl}> Copy Link </a>
                                    </td>
                                    <td>
                                        <a className="btn btn-primary" onClick={this.openEdit.bind(this, tweak)}> Edit </a>
                                    </td>
                                    <td>
                                        <a className="btn btn-danger" onClick={this.deleteTweak.bind(this, tweak)}> Delete </a>
                                    </td>
                                </tr>
                            })}
                        </tbody>
                    </table>
                    <Dialog
                        modal={true}
                        open={this.state.openEdit}
                        contentStyle={customContentStyleEdit}
                        >
                        <h4>Edit Tweak</h4>
                        
                        <div className="table-responsive" style={{marginTop:"45px"}}>          
                            <table className="table table-borderless table-condensed table-hover">
                                <tbody>
                                    <tr>
                                        <td>Title</td>
                                        <td>
                                            <textarea rows="3" style={{width:"200px", resize: "none"}} value={this.state.title} maxLength="42" onChange={this.handleChange.bind(this,'title')}></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Categories</td>
                                        <td>
                                    <textarea maxLength="200" style={{width:"200px", resize: "none"}} ref="comments" className="form-control" rows="3" id="comment" placeholder="Add Comments and #Tags (Optional)" value={this.state.selectedCategorieNames} onClick={this.openCategory.bind(this)}></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Status</td>
                                        <td>
                                            <select id="selectstatus">
                                              <option value='1'>Active</option>
                                              <option value='2'>Suspended</option>
                                            </select> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Picks</td>
                                        <td>
                                            <select id="selectpicks">
                                              <option value='1'>Yes</option>
                                              <option value='0'>No</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="pull-right" style={{marginTop:"5px"}}>
                            <FlatButton id="close" label="Close" primary={true} onClick={this.closeEdit.bind(this)} />
                            <FlatButton id="done" label="Update" secondary={true} onClick={this.updateTweak.bind(this)} />
                        </div>
                    </Dialog>
                    <Dialog
                        modal={true}
                        open={this.state.openCategories}
                        contentStyle={customContentStyleCategory}
                        >
                        <h4>Select upto 3 Categories (Required)</h4>
                        {
                            (this.state.selectedCategories == "") ?
                            (
                                <div className="pull-right" style={{marginTop:"5px"}}>
                                    <FlatButton id="cleard" label="Clear" disabled={true} />
                                    <FlatButton id="doned" label="Next" disabled={true} />
                                 </div>
                            ) :
                            (
                                <div className="pull-right" style={{marginTop:"5px"}}>
                                    <FlatButton id="clear" label="Clear" primary={true} onClick={this.clearCategory.bind(this)} />
                                    <FlatButton id="done" label="Next" secondary={true} onClick={this.doneCategory.bind(this)} />
                                    
                                </div>
                            )
                        }
                            <br/>
                       <div style={{marginTop:"20px"}}>
                        <CheckboxGroup
                            name="categories"
                            value={this.state.selectedCategories}
                            ref="categoryGroup"
                            onChange={this.handleCategory.bind(this)}
                            >
                            {this.state.categories.map((category,key) => 

                                <div className="col-md-4" style={{marginBottom:"5px"}} >
                                    <input type="checkbox" className="check" id={category._id} value={category._id}/>
                                    &nbsp;&nbsp;<span style={{fontSize: "110%"}}>{category.categoryname}</span>

                                </div>
                            )}
                        </CheckboxGroup>
                        </div>
                    </Dialog>
                </div>
            )
            
        }
    }
}


export default Tweaks;