require('babel-core/register');
require('./server.es6');
