var localhost = "http://localhost:9014/";
var development = "http:development.myappdemo.net:9014/";
//var production = "http://xyzies.herokuapp.com/";

module.exports = development;