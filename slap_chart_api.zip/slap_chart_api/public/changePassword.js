APP=React.createClass({  

    getInitialState: function() {
        return({ 
            "id": window.location.pathname,
            "url": '',
            "pwd": '',
            "repwd": '',
            "route":'0'
        })
    },

    componentWillMount:function() {
        var url=window.location.protocol+"//"+window.location.hostname+":"+window.location.port;
        alert("Hi")
        this.setState({'url':url});
        var id=this.state.id;
        id = id.replace("/", '');
        this.setState({"id":id});
    },
    
    handelSubmit: function() {
        if(this.state.pwd==this.state.repwd && this.state.pwd.length>3) {
            var id = this.state.id;
            id = id.substr(id.indexOf("/") + 1);
            id = id.replace("/", '');
            var pwd = this.state.pwd;
            var url = this.state.url;
           // var data="mutation M{changePassword(userId:\""+id+"\",password:\""+pwd+"\"){_id,password}}";
            var success="";

            var data={'userId':id,'password':pwd};
            console.log("data:"+JSON.stringify(data))
            $.ajax({
                url:"http://localhost:7202/api/user/changePassword",
                dataType: 'json',
                type: 'POST',
                data: data,
                success: function(users) {
                    
                    if(users.status=="Failed"){
                        alert("Password not changed.");
                    } else {
                        alert("Password changed Successfully.");
                        this.setState({"route":1});
                    }
                    

                }.bind(this),
                error: function(xhr, status, err) {
                    console.error(this.props.url, status, err.toString());
                }.bind(this)
            });


           /* $.ajax({
                type: "POST",
                url: url,
                contentType: "application/graphql",
                data: data,
                success: function(msg){
                    console.log(JSON.stringify(msg));
                    alert("Password changed Successfully.");
                    this.setState({"route":1});
                }.bind(this)
            })*/
        }
        else if(this.state.pwd!=this.state.repwd){
            alert("Password and Re-type Password should be same.");
            this.setState({"pwd":""});
            this.setState({"repwd":""});
        }
        else {
            alert("Password should contain minimum 4 charecters.");
            this.setState({"pwd":""});
            this.setState({"repwd":""});
        }
    },

    handleChange: function(type,e) {
        var change = {};
        change[type] = e.target.value;
        this.setState(change);
    },

    cancel: function() {
        this.setState({"pwd":""});
        this.setState({"repwd":""});
    },

    render: function()
    {
        var center={
           textAlign:"center"
        }
        var style={
            marginTop: 10
        }

        if(this.state.route==0) {
            return(
                <div className="form-horizontal">
                    <div className="container">

                        <div className="row"  style={style}>
                            <div className="col-sm-12">
                                <h1  style={center}>Reset your Roger Password here..</h1>
                            </div>     
                        </div>

                        <div className="row"  style={style}>
                            <label className="control-label col-sm-5">Password: </label>
                            <div className="col-sm-7">
                                <input type="password" name="pwd" ref="pwd" value={this.state.pwd} onChange={this.handleChange.bind(this,'pwd')} />
                            </div> 
                        </div>

                        <div className="row"  style={style}>
                            <label className="control-label col-sm-5">Re-type Password: </label>
                            <div className="col-sm-7">
                                <input type="password" name="repwd" ref="repwd" value={this.state.repwd} onChange={this.handleChange.bind(this,'repwd')} />
                            </div> 
                        </div>

                        <div className="row"  style={style}>
                            <div className=" col-sm-5"></div>
                            <div className=" col-sm-1">
                                <input type="button" name="submit" value="Submit" onClick={this.handelSubmit} />
                            </div>
                            <div className="col-sm-1">
                                <input type="button" name="cancel" value="Cancel" onClick={this.cancel} />
                            </div> 
                            <div className=" col-sm-5"></div>
                        </div>
                    </div>
                </div>
            )
        }
        else {
            return(
                <div className="form-horizontal">
                    <div className="container" style={center}>
                        <h1>Thank you for changing password..!</h1>
                    </div>
                </div>
            )
        }
    }
});

