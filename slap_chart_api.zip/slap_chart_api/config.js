module.exports={
	sendgrid_username: 'mybusinessapp',
	sendgrid_password: 'hangten#12',
	api_username: 'SENDGRID_USERNAME',
	api_password: 'SENDGRID_PASSWORD',
	dbUrl:'mongodb://localhost:27017/slapchart'
}
