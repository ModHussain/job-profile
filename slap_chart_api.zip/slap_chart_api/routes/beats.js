var express = require('express');
var router = express.Router();
var db=require("../db.js")

var _ =require('underscore');

router.post('/addBeat/:userId', function (req, res) {
	db.User.findOne({_id:req.params.userId},function(err,user){
		if(user==undefined){
			var message = JSON.parse('{"status":"success","message":"Producer does not exist"}');
                res.send(message)
		} else {

		  var beatcount=user.beatCount;
			beatcount=parseInt(beatcount)+1;
			var newBeat=new db.Beats({userId:req.params.userId, media:req.body.media, mediaSource:req.body.mediaSource,title:req.body.title,status:"reviewed"})
			newBeat.save(function(err,beat){

			   db.User.update({_id:req.params.userId},{$set:{beatCount:parseInt(beatcount)}},function(err,updateUser){

            })

				var message = JSON.parse('{"status":"success","message":' + JSON.stringify(beat) + '}');
                res.send(message)
			})
		}
	})
})

router.get('/producers:id/submittedBeats/:limit', function (req, res) {
	var start=parseInt(req.params.limit);
	db.Beats.find({isDeleted:{$ne:true},userId:req.params.id}).sort({createdDate:-1}).exec(function(err,beatsData){
		db.Beats.find({isDeleted:{$ne:true},userId:req.params.id}).skip(start).limit(20).sort({createdDate:-1}).exec(function(err,beats){
			db.User.findOne({_id:req.params.id},function(err,user){
				var dataObj={};
				var selectedCount=0;
				var submittedCount=0;
				var totalCount=0;
				if(beats == ''){

					dataObj={
						userName:user.userName,
						isFeatured:user.isFeatured,
						isBlocked:user.isBlocked,
						profilePic:user.profilePic,
						logo:user.logo,
						totalCount:beatsData.length,
						submittedCount:beatsData.length,
						selectedCount:selectedCount,
						beats:beats
					}
					var message = JSON.parse('{"status":"failed","message":' + JSON.stringify(dataObj) + '}');
		                res.send(message)
		        } else {

		        	_.each(beats,function(beat){
		        		if((beat.status=="queue") || (beat.status=="live")){
		        			selectedCount++;
		        		}
		        	})

					/*beats[0].profilePic=user.profilePic;
					beats[0].logo=user.logo;
					beats[0].submittedCount=beats.length;
					beats[0].selectedCount=selectedCount;*/

					dataObj={
						userName:user.userName,
						isFeatured:user.isFeatured,
						isBlocked:user.isBlocked,
						profilePic:user.profilePic,
						logo:user.logo,
						totalCount:beatsData.length,
						submittedCount:beats.length,
						selectedCount:selectedCount,
						beats:beats

		        	}

	    			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(dataObj) + '}');
	        		res.send(message)
		        }
	    	})
	    })
	})
})

router.get('/allSubmittedBeats/:limit', function (req, res) {
	var start=20;
    var limit=parseInt(req.params.limit);
	db.Beats.find({isDeleted:{$ne:true},status:"live"}).exec(function(err,beats){
		if(beats == ''){
			var message = JSON.parse('{"status":"failed","message":' + JSON.stringify(beats) + '}');
                res.send(message)
        } else {
        	var resArray=[];
        	var beatLen=beats.length;
        	console.log("beatLen:"+beatLen)
        	_.each(beats,function(beat){
        		db.User.findOne({_id:beat.userId},function(err,user){
                   if(user.isDeleted==false)
				     {
        			var data={
	        			userName:user.userName,
	        			profilePic:user.profilePic,
	        			logo:user.logo,
	        			title:beat.title,
	        			media:beat.media,
	        			userId:beat.userId,
	        			mediaSource:beat.mediaSource,
	        			createdDate:beat.createdDate,
	        			userId:beat.userId
	        		}
	        		resArray.push(data)
					}
	        		beatLen--;
	        		if(beatLen<=0){

                        //resArray=sortDataDesc(resArray)
	        			//var message = JSON.parse('{"status":"success","message":' + JSON.stringify(resArray) + '}');
                		//res.send(message)

                		var totalCount=resArray.length;
	        			if(resArray==''){
	        				var message = JSON.parse('{"status":"success","message":' + JSON.stringify(resArray) + '}');
	            			res.send(message);

	                    } else {

	                        resArray[0].totalCount=totalCount;

					         finalArray=resArray.sort(function (a, b) {
	                           a = new Date(a.createdDate);
	                            b = new Date(b.createdDate);
	                           return a > b ? -1 : a < b ? 1 : 0;
	                           });

	                        finalArray=resArray.slice(limit,start+limit);


	        				var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
	            			res.send(message);
	                    }
	        		}
        		})

        	})

        }
    })
})

//db.datecol.find({"date": {$gte: (new Date((new Date()).getTime() - (15 * 24 * 60 * 60 * 1000)))}}).sort({ "date": -1 })
function sortDataDesc(data){
	data.sort(function (a, b) {
	    a = new Date(a.createdDate);
	    b = new Date(b.createdDate);
	    return a > b ? -1 : a < b ? 1 : 0;
	});
	return data;
}

function sortDataAsc(data){
	data.sort(function (a, b) {
	    a = new Date(a.createdDate);
	    b = new Date(b.createdDate);
	    return a > b ? 1 : a < b ? -1 : 0;
	});
	return data;
}

function sortDataAsc(data){
	data.sort(function (a, b) {
	    a = new Date(a.createdDate);
	    b = new Date(b.createdDate);
	    return a > b ? 1 : a < b ? -1 : 0;
	});
	return data;
}

function queuedDateAsc(data){
	data.sort(function (a, b) {
	    a = new Date(a.queuedDate);
	    b = new Date(b.queuedDate);
	    return a > b ? 1 : a < b ? -1 : 0;
	});
	return data;
}

function queuedDateDesc(data){
	data.sort(function (a, b) {
	    a = new Date(a.queuedDate);
	    b = new Date(b.queuedDate);
	    return a > b ? 1 : a < b ? -1 : 0;
	});
	return data;
}

/*exports.listBeatsForAdmin = function (req, res) {
	var query='';
	if(req.body.status=="reviewed"){
		query=db.Beats.find({status:"reviewed",createdDate: {$gte: (new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))}})
	}
	if(req.body.status=="queue"){
		query=db.Beats.find({status:"queue"})
	}
	if(req.body.status=="live"){
		query=db.Beats.find({status:"live"})
	}
	//console.log("hjksdadjhadgaj:"+((new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))))

	query.exec(function(err,beats){
		if(beats == ''){
			var message = JSON.parse('{"status":"failed","message":' + JSON.stringify(beats) + '}');
                res.send(message)
        } else {
        	var finalArray=[];
        	var start=5;
        	var limit=parseInt(req.params.limit);
        	var resArray=[];
        	var isFeaturedFalse=[];
        	var isFeaturedTrue=[];
        	var isBlockedTrue=[];
        	var beatLen=beats.length;
        	console.log("beatLen:"+beatLen)
        	_.each(beats,function(beat){
        		db.User.findOne({_id:beat.userId},function(err,user){
        			var data={
	        			userName:user.userName,
	        			profilePic:user.profilePic,
	        			logo:user.logo,
	        			title:beat.title,
	        			isFeatured:user.isFeatured,
	        			isBlocked:user.isBlocked,
	        			media:beat.media,
	        			mediaSource:beat.mediaSource,
	        			createdDate:beat.createdDate,
	        			status:beat.status,
	        			beatId:beat._id
        			}
        			if(req.body.status=="reviewed"){
	        			if((user.isFeatured==true) && (user.isBlocked==false)){

		        			isFeaturedTrue.push(data)
	        			}
	        			if((user.isFeatured==false) && (user.isBlocked==false)){   //isFeatured is FALSE condition

		        			isFeaturedFalse.push(data)
	        			}
	        			//console.log("isFeaturedFalse:"+JSON.stringify(isFeaturedFalse))
	        			if(user.isBlocked==true){

		        			isBlockedTrue.push(data)
	        			}
        			}
	        		if(req.body.status=="queue"){
	        			resArray.push(data)
	        		}
	        		if(req.body.status=="live"){
	        			resArray.push(data)
	        		}
	        		beatLen--;
	        		if(beatLen<=0){
	        			if(req.params.type=="asc"){   //ascending order
	        				if()
	        				isFeaturedTrue=sortDataAsc(isFeaturedTrue);
		        			isFeaturedFalse=sortDataAsc(isFeaturedFalse);
		        			isBlockedTrue=sortDataAsc(isBlockedTrue);
	        			} else{
	        				isFeaturedTrue=sortDataDesc(isFeaturedTrue);
		        			isFeaturedFalse=sortDataDesc(isFeaturedFalse);
		        			isBlockedTrue=sortDataDesc(isBlockedTrue);
	        			}

	        			var finalRes=isFeaturedTrue.concat(isFeaturedFalse);
	        			 	finalArray=finalRes.concat(isBlockedTrue);
	        			var totalCount=finalArray.length;

	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {
                            finalArray[0].totalCount=totalCount;
                            var finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }

	        		}
        		})
        	})
        }
    })
}
*/

router.get('/listAllBeats/:type/:limit', function (req, res) {
	//console.log("hjksdadjhadgaj:"+((new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))))
	db.Beats.find({isDeleted:{$ne:true},status:"reviewed",createdDate: {$gte: (new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))}}).exec(function(err,beats){
		if(beats == ''){
			var message = JSON.parse('{"status":"failed","message":' + JSON.stringify(beats) + '}');
                res.send(message)
        } else {
        	var finalArray=[];
        	var start=20;
        	var limit=parseInt(req.params.limit);
        	var resArray=[];
        	var isFeaturedFalse=[];
        	var isFeaturedTrue=[];
        	var isBlockedTrue=[];
        	var isFlagedArr=[];
        	var beatLen=beats.length;
        	console.log("beatLen:"+beatLen)
        	_.each(beats,function(beat){
        		var color='';
        		if(beat.isFlaged==true){
        			db.User.findOne({_id:beat.flagedUserId},function(err,flageduser){
        				color=flageduser.flagColorCode
        			})
        		}
        		db.User.findOne({_id:beat.userId},function(err,user){
				 if(user.isDeleted==false)
				 {
        			console.log("user:"+user._id)
        			var data={
	        			userName:user.userName,
	        			profilePic:user.profilePic,
	        			logo:user.logo,
	        			title:beat.title,
	        			isFeatured:user.isFeatured,
	        			isBlocked:user.isBlocked,
	        			media:beat.media,
	        			mediaSource:beat.mediaSource,
	        			createdDate:beat.createdDate,
	        			status:beat.status,
	        			beatId:beat._id,
	        			userId:beat.userId,
	        			flagColorCode:color,
	        			isFlaged:(beat.isFlaged==null)?(false):(beat.isFlaged),
	        			flagedUserId:(beat.flagedUserId==null)?(null):(beat.flagedUserId)
        			}
        			//console.log("if condition:"+beat)
        			if(beat.isFlaged==true){
        				console.log("if condition")
        				isFlagedArr.push(data)
        			}

        			if((user.isFeatured==true) && (user.isBlocked==false) && (beat.isFlaged==false)){

	        			isFeaturedTrue.push(data)
        			}

        			if((user.isFeatured==false) && (user.isBlocked==false) && (beat.isFlaged==false)){   //isFeatured is FALSE condition

	        			isFeaturedFalse.push(data)
        			}
        			//console.log("isFeaturedFalse:"+JSON.stringify(isFeaturedFalse))
        			if(user.isBlocked==true && (beat.isFlaged==false)){

	        			isBlockedTrue.push(data)
        			}
					}

	        		beatLen--;
	        		if(beatLen<=0){
	        			if(req.params.type=="asc"){   //ascending order
	        				isFlagedArr=sortDataAsc(isFlagedArr);
	        				isFeaturedTrue=sortDataAsc(isFeaturedTrue);
		        			isFeaturedFalse=sortDataAsc(isFeaturedFalse);
		        			isBlockedTrue=sortDataAsc(isBlockedTrue);

	        			} else{
	        				isFlagedArr=sortDataDesc(isFlagedArr);
	        				isFeaturedTrue=sortDataDesc(isFeaturedTrue);
		        			isFeaturedFalse=sortDataDesc(isFeaturedFalse);
		        			isBlockedTrue=sortDataDesc(isBlockedTrue);

	        			}
	        			var arrayRes=isFlagedArr.concat(isFeaturedTrue);
	        			var finalRes=arrayRes.concat(isFeaturedFalse);
	        			 	finalArray=finalRes.concat(isBlockedTrue);
	        			var totalCount=finalArray.length;


	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {

                            finalArray[0].totalCount=totalCount;
                            var finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }

	        		}
        		})
        	})
        }
    })
})

router.get('/beatsByStatus/:status/:type/:limit', function (req, res) {
	//console.log("hjksdadjhadgaj:"+((new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))))
	db.Beats.find({isDeleted:{$ne:true},status:req.params.status}).exec(function(err,beats){
		if(beats == ''){
			var message = JSON.parse('{"status":"failed","message":' + JSON.stringify(beats) + '}');
                res.send(message)
        } else {
        	var finalArray=[];
        	var start=20;
        	var limit=parseInt(req.params.limit);
        	var resArray=[];

        	var beatLen=beats.length;
        	console.log("beatLen:"+beatLen)
        	_.each(beats,function(beat){
        		db.User.findOne({_id:beat.userId},function(err,user){
				   var createDate="";
					 if(req.params.status=="live")
					 {
					  createDate=beat.publishedDate;
					 }

					  if(req.params.status=="queue")
					  {
					    createDate=beat.queuedDate;
					  }
					   if(req.params.status=="reviewed")
					  {
					    createDate=beat.createdDate;
					  }
					  if(user.isDeleted==false)
				     {
        			var data={
	        			userName:user.userName,
	        			userId:user._id,
	        			profilePic:user.profilePic,
	        			logo:user.logo,
	        			title:beat.title,
	        			isFeatured:user.isFeatured,
	        			isBlocked:user.isBlocked,
	        			media:beat.media,
	        			queuedDate:beat.queuedDate,
	        			publishedDate:beat.publishedDate,
	        			mediaSource:beat.mediaSource,
	        			createdDate:createDate,
	        			status:beat.status,
	        			beatId:beat._id
        			}
	        		resArray.push(data)
					}
	        		//console.log("resArray:"+JSON.stringify(resArray))
	        		beatLen--;
	        		console.log("len-----"+beatLen)
	        		if(beatLen<=0){
	        			if(req.params.status=="queue"){
	        				console.log("Queuevkfdsjfdkshfd")
	        				if(req.params.type=="asc"){

								//resArray=queuedDateAsc(resArray)
								resArray.sort(function (a, b) {
								    a = new Date(a.queuedDate);
								    b = new Date(b.queuedDate);
								    return a > b ? 1 : a < b ? -1 : 0;
								});
	        				} else {

								//resArray=queuedDateDesc(resArray)
								resArray.sort(function (a, b) {
								    a = new Date(a.queuedDate);
								    b = new Date(b.queuedDate);
								    return a > b ? -1 : a < b ? 1 : 0;
								});
	        				}

	        			} else {
	        				console.log("live jndksfjdhsfjdsf")
	        				if(req.params.type=="asc"){
	        						resArray.sort(function (a, b) {
								    a = new Date(a.publishedDate);
								    b = new Date(b.publishedDate);
								    return a > b ? 1 : a < b ? -1 : 0;
								});
	        				} else {
	        					resArray.sort(function (a, b) {
								    a = new Date(a.publishedDate);
								    b = new Date(b.publishedDate);
								    return a > b ? -1 : a < b ? 1 : 0;
								});
	        				}
	        			}

	        			var totalCount=resArray.length;
	        			if(resArray==''){
	        				var message = JSON.parse('{"status":"success","message":' + JSON.stringify(resArray) + '}');
	            			res.send(message);

	                    } else {

	                        resArray[0].totalCount=totalCount;
	                        finalArray=resArray.slice(limit,start+limit);

	        				var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
	            			res.send(message);
	                    }

	        		}
        		})
        	})
        }
    })
})


router.get('/searchBeats/:status/:userName/:type/:limit',function (req, res) {
	var query='';
	var start=20;
    var limit=parseInt(req.params.limit);

	if(req.params.status=="reviewed"){
		query=db.Beats.find({isDeleted:{$ne:true},status:req.params.status,"createdDate": {$gte: (new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))}})
	}
	if(req.params.status=="queue"){
		console.log("req.params.status:"+req.params.status)
		query=db.Beats.find({isDeleted:{$ne:true},status:req.params.status})
	}
	if(req.params.status=="live"){
		query=db.Beats.find({isDeleted:{$ne:true},status:req.params.status})
	}


	query.exec(function(err,beats){
		if(beats == ''){
			var message = JSON.parse('{"status":"failed","message":' + JSON.stringify(beats) + '}');
                res.send(message)
        } else {
        	var resArray=[];
        	var beatLen=beats.length;
        	console.log("beatLen:"+beatLen)
        	_.each(beats,function(beat){

			    var color='';
        		if(beat.isFlaged==true){
        			db.User.findOne({_id:beat.flagedUserId,isDeleted:{$ne:true}},function(err,flageduser){
        				color=flageduser.flagColorCode
        			})
        		}
        		db.User.findOne({_id:beat.userId},function(err,user){
        			if(user.userName.toLowerCase().indexOf(req.params.userName.toLowerCase()) > -1){
					 var createDate="";
					 if(req.params.status=="live")
					 {
					  createDate=beat.publishedDate;
					 }

					  if(req.params.status=="queue")
					  {
					    createDate=beat.queuedDate;
					  }
					   if(req.params.status=="reviewed")
					  {
					    createDate=beat.createdDate;
					  }
					   if(user.isDeleted==false)
				     {
	        			var data={
		        			userName:user.userName,
		        			profilePic:user.profilePic,
		        			logo:user.logo,
		        			title:beat.title,
		        			isFeatured:user.isFeatured,
		        			isBlocked:user.isBlocked,
		        			media:beat.media,
		        			mediaSource:beat.mediaSource,
		        			createdDate:createDate,
		        			status:beat.status,
		        			userId:beat.userId,
							flagColorCode:color,
	        			    isFlaged:(beat.isFlaged==null)?(false):(beat.isFlaged),
	        			    flagedUserId:(beat.flagedUserId==null)?(null):(beat.flagedUserId)
	        			}
		        		resArray.push(data)

		        	}
					}
	        		beatLen--;
	        		if(beatLen<=0){

					    var totalCount=resArray.length;
						resArray[0].totalCount=totalCount;
                        resArray=resArray.slice(limit,start+limit);
						if(req.params.type=="asc")
						{   //ascending order
	        			resArray=sortDataAsc(resArray);
				     	}
						else
						{
	        			resArray=sortDataDesc(resArray);
						}

						var message = JSON.parse('{"status":"success","message":' + JSON.stringify(resArray) + '}');
                		res.send(message)
	        		}
        		})
        	})
        }
    })
})



router.get('/cronjob', function(req,res){
	console.log("jssahjahdgashds")
	//db.Beats.find({status:"queue", queuedDate: {$gte: (new Date((new Date()).getTime() - (5 * 24 * 60 * 60 * 1000)))}}).sort({queuedDate:1}).exec(function(err,beats){
		db.Beats.find({isDeleted:{$ne:true},status:"queue"}).sort({queuedDate:1}).exec(function(err,beats){
		if(beats==''){
			console.log("Beats are Empty")
		} else{
             var displayBeats;
			var totalBeats=(beats.length);
			console.log("totalBeats:"+totalBeats)
			if(totalBeats >= 5)
			displayBeats =parseInt(totalBeats/5);

		   else
            displayBeats=parseInt(totalBeats);

			console.log("displayBeats:"+displayBeats)
			var i=1;
			var resArray=[];
			_.each(beats,function(beat){

				if(i<=displayBeats){
					db.Beats.update({_id:beat._id},{$set:{status:"live", publishedDate:Date.now()}},function(err,liveData){
						console.log("update status to live:"+JSON.stringify(liveData))
					})
				}
				i++;
			})
		}
	})
})

router.put('/updateBeatStatus/:id', function (req, res) {
    db.Beats.findOne({_id:req.params.id},function(err,beat){

        if(beat==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Beat was not found."}');
            res.send(message)
        }
        else {
            db.Beats.update({_id:req.params.id}, {$set:{ status:req.body.status,queuedDate:Date.now()}},function(err,result) {
                console.log("Update result:"+JSON.stringify(result))
                var message = JSON.parse('{"status":"success","message":"Beat status updated successfully"}');
                res.send(message)
            })
        }
    })
})

router.put('/updateFlag/:id', function (req, res) {
    db.Beats.findOne({_id:req.params.id},function(err,beat){

        if(beat==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Beat was not found."}');
            res.send(message)
        }
        else {
            db.Beats.update({_id:req.params.id}, {$set:{ isFlaged:req.body.flaged,flagedUserId: req.body.userId, flagedDate:Date.now()}},function(err,flagResult) {
                console.log("Update flagResult:"+JSON.stringify(flagResult))
                var message = JSON.parse('{"status":"success","message":"Beat flaged successfully"}');
                res.send(message)
            })
        }
    })
})

router.delete('/beats/:id', function (req, res) {
    db.Beats.findOne({_id:req.params.id},function(err,user){
        if(user==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Producer was not found."}');
            res.send(message)
        }
        else {
		     var userId=user.userId;
			 db.User.findOne({_id:userId},function(err,userbeat){
			 var beatcount=userbeat.beatcount;

			 db.User.update({_id:userId},{$set:{beatCount:parseInt(beatcount)-1}},function(err,updateUser){

            })

			 });
            db.Beats.update({_id:req.params.id}, {$set:{ isDeleted:true}},function(err,result) {



                var message = JSON.parse('{"status":"success","message":"Beat deleted successfully"}');
                res.send(message)
            })
        }
    })
})

module.exports = router;
