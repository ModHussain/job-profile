exports.auth = require('./auth');
exports.beats = require('./beats');
exports.activities = require('./activities');
exports.users = require('./users');
