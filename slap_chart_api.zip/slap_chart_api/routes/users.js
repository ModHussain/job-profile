//users.js lines
var express = require('express');
var router = express.Router();
var db=require("../db.js")

var bcrypt = require('bcryptjs');
var mainUrl =require('../public/url')
var SALT_WORK_FACTOR = 10;
var nodemailer = require("nodemailer");
var sgTransport = require('nodemailer-sendgrid-transport');
var _ =require('underscore');
var SENDGRID_USERNAME = "mybusinessapp";
var SENDGRID_PASSWORD = "hangten#12";


//User signup
router.post('/producers',function (req, res) {
  console.log("Add producers api called");
    db.User.findOne({email:req.body.email.toLowerCase()},function(err,user){
        var resArray=[];
        if(user==undefined){
            bcrypt.genSalt(SALT_WORK_FACTOR, function (err, salt) {
                if (err) {
                    res.send(err)
                }
                bcrypt.hash(req.body.password, salt, function (err, hash) {
                    if (err) {
                        res.send(err)

                    }
                    else {

                        var newUser=new db.User({userName:req.body.userName, email:req.body.email.toLowerCase(),password:hash})
                        newUser.save(function(err,user1){

                            var options = {
                                auth: {
                                    api_user: SENDGRID_USERNAME,
                                    api_key: SENDGRID_PASSWORD
                                }
                            }

                            var smtpTransport = nodemailer.createTransport(sgTransport(options));
                            var mailOptions = {
                                to: user1.email,
                                from: 'info@slapchart.com',
                                subject: 'Welcome to SlapChart',
                                text:'Hello '+user1.userName+'\n\nThank you for signing up on SlapChart.'
                            };
                            smtpTransport.sendMail(mailOptions, function (err) {
                                if (err) {
                                    console.log("Failed to send email.");
                                }
                                else {

                                    var message = JSON.parse('{"status":"success", "message":"You have successfully created an account!","user":' + JSON.stringify(user1) + '}');
                                    res.send(message)
                                }
                            });



                        })
                    }
                })
            })
        } else {

            var message = JSON.parse('{"status":"failed","message":"Sorry, the email already exist","user":' + JSON.stringify(resArray) + '}');
            res.send(message)
        }
    })
})

// User login
router.post('/producers/login', function (req, res) {
	db.User.findOne({'email':req.body.email.toLowerCase()}).then(function(user)  {
        if(user == undefined) {
            var message = JSON.parse('{"status":"failed","message":"The email you`ve entered doesn`t match any account."}');
            res.send(message)
        } else {

            bcrypt.compare(req.body.password, user.password,function(err, match){
                if(match) {
                    var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user) + '}');
                    res.send(message)
                }
                else {
                    var message = JSON.parse('{"status":"failed","message":"The password you`ve entered is invalid."}');
                    res.send(message)
                }
            })
        }
    })
})

//Admin Login
router.post('/adminlogin', function (req, res) {
   console.log('adminlogin');
	db.User.findOne({'userName':req.body.email.toLowerCase()}).then(function(user)  {
        if(user == undefined) {
            var message = JSON.parse('{"status":"failed","message":"The user name you`ve entered doesn`t match any account."}');
            res.send(message)
        } else {

            bcrypt.compare(req.body.password, user.password,function(err, match){
                if(match) {
                    var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user) + '}');
                    res.send(message)
                }
                else {
                    var message = JSON.parse('{"status":"failed","message":"The password you`ve entered is invalid."}');
                    res.send(message)
                }
            })
        }
    })
})


// Forgot password
router.post('/producers/:id/passwordassistence', function (req, res) {
    db.User.findOne({'email': req.body.email}).then(function(user) {
        if(user == undefined) {
            var message = JSON.parse('{"status":"failed","message":"The email you`ve entered doesn`t match an existing account."}');
            res.send(message)
        }
        else {
            var options = {
                auth: {
                    api_user: SENDGRID_USERNAME,
                    api_key: SENDGRID_PASSWORD
                }
            }
            var url = "";
            url = mainUrl;
            url += "forgotpassword/";
            url += user._id;
            var smtpTransport = nodemailer.createTransport(sgTransport(options));
            var mailOptions = {
                to: user.email,
                from: 'info@slapchat.com',
                subject: 'Reset Password',
                text:'This email has been sent to you as part of your request to reset your password. In order to complete the password reset process, you must click on the link below and follow the on-screen instructions. \n\n'+url+'\n\nIf you did not request for a new password, please contact your admin immediately.\n\nThis email is System generated please do not replay to this.\n'
            };
            smtpTransport.sendMail(mailOptions, function (err) {
                if (err) {
                    reject("Failed to send email.");
                    var message = JSON.parse('{"status":"failed","message":"Failed to send email."}');
            		res.send(message)
                }
                else {
                    var message = JSON.parse('{"status":"success","message":"Mail sent successfully."}');
            		res.send(message)
                }
            });
        }
    })
})

// Change password for forgot password
router.put('/producers/:id/forgotpassword',function (req, res) {
    db.User.findOne({_id:req.params.id},function(err,user) {
        if(user==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Producer was not found."}');
            res.send(message)
        }
        else {
            bcrypt.genSalt(SALT_WORK_FACTOR, function (err, salt) {
                if (err) {
                    reject(err)
                }
                else {
                    bcrypt.hash(req.body.password, salt, function (err, hash) {
                        if (err) {
                            reject(err)
                        }
                        else {
                            var hashPassword = hash;
                            db.User.update({_id:req.params.id}, {$set:{ password:hashPassword }},function(err,result) {
                                var message = JSON.parse('{"status":"success","message": "Your Password has been successfully changed!"}');
                                res.send(message)
                            })
                        }
                    });
                }
            })
        }
    })
})

// Change user name
/*exports.changeUserName = function (req, res) {
    db.User.findOne({_id:req.params.id},function(err,user) {
        if(user==undefined) {
            var message = JSON.parse('{"status":"success","message":"Producer was not found."}');
            res.send(message)
        }
        else {
            db.User.update({_id:req.params.id}, {$set:{ userName:req.body.userName}},function(err,result) {
                var message = JSON.parse('{"status":"success","message":"Your User Name has been successfully changed!"}');
                res.send(message)
            })
        }
    })
}*/

//GET,PUT,DEL User By id
router.route('/producers/:id')
// User by Id
     .get(function (req, res) {
	db.User.findOne({_id:req.params.id}).exec(function(err, user)  {
        var submittedBeats=0;
        var selectedBeats=0;
        if(!user){
            var message = JSON.parse('{"status":"failed","message":"Producer does not exist"}');
                res.send(message)
        } else {
            db.Beats.find({isDeleted:{$ne:true},userId:req.params.id},function(err,beats){
                submittedBeats=beats.length;
                _.each(beats,function(beat){
                    if((beat.status=="queue") || (beat.status=="live")){
                        selectedBeats++;
                    }
                })
                user.submittedBeats=submittedBeats;
                user.selectedBeats=selectedBeats;

                var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user) + '}');
                res.send(message)
            })
        }
    });
})
// Update profile
      .put(function (req, res) {
    db.User.findOne({_id:req.params.id},function(err,user) {
        if(user == undefined) {
            var message = JSON.parse('{"status":"failed","message":"Producer was not found."}');
            res.send(message)
        }
        else {
//contactEmail:req.body.contactEmail,cloudUri:req.body.cloudUri,twitterUri:req.body.twitterUri,facebookUri:req.body.facebookUri,homeUri:req.body.homeUri,instagramUri:req.body.instagramUri,profilePic:req.body.profilePic,logo:req.body.logo,isProfileUpdate:req.body.isProfileUpdate
                 db.User.update({_id:req.params.id}, {$set:{ contactEmail:req.body.contactEmail,cloudUri:req.body.cloudUri,twitterUri:req.body.twitterUri,facebookUri:req.body.facebookUri,homeUri:req.body.homeUri,instagramUri:req.body.instagramUri,profilePic:req.body.profilePic,logo:req.body.logo,isProfileUpdate:req.body.isProfileUpdate}},function(err,result){
                    console.log("result:"+JSON.stringify(result))
                    var message = JSON.parse('{"status":"success","message":"Your Profile has been successfully changed!"}');
                    res.send(message)
                })
           // }
        }
    })
})
//DELETE USER
     .delete(function (req, res) {
    db.User.findOne({_id:req.params.id},function(err,user){
        if(user==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Producer was not found."}');
            res.send(message)
        }
        else {
            db.User.update({_id:req.params.id}, {$set:{ isDeleted:true}},function(err,result) {
                var message = JSON.parse('{"status":"success","message":"User deleted successfully"}');
                res.send(message)
            })
        }
    })
})


// CHANGE USERNAME
router.put('/producers/:id/username', function (req, res) {
  db.User.findOne({email:req.body.email.toLowerCase()},function(err,user){
    if(user==undefined) {
      var message = JSON.parse('{"status":"failed","message":"The email you`ve entered doesn`t match any account."}');
        res.send(message)
          } else {
            bcrypt.genSalt(SALT_WORK_FACTOR, function (err, salt) {
                if (err) {
                    reject(err)
                } else {
                    bcrypt.hash(req.body.password, salt, function (err, hash) {
                        if (err) {
                            reject(err)
                        }
                        else {
                            var hashPassword = hash;
                             bcrypt.compare(req.body.password, user.password, function (err, match) {
                                if(match){
                                    db.User.update({email:req.body.email}, {$set:{ userName:req.body.userName }},function(err,result){
                                        var message = JSON.parse('{"status":"success","message": "Your User Name has been successfully changed!"}');
                                        res.send(message)
                                    })
                                } else {

                                    var message = JSON.parse('{"status":"failed","message":"The password you`ve entered doesn`t match."}');
                                    res.send(message)
                                }

                            })
                        }
                    })
                }
            })
        }
    })
})

// List users
router.get('/searchuser/:userName/:limit', function (req, res) {

     var start=20;
        var limit=parseInt(req.params.limit);
		var resArray=[];
        	var isFeaturedFalse=[];
        	var isFeaturedTrue=[];
        	var isBlockedTrue=[];
        	var isFlagedArr=[];

    db.User.find({isDeleted:false}).sort({_id:-1}).exec(function(err,users) {
        if(users==''){
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(users) + '}');
            res.send(message)
        } else {
		        var userLen=users.length;
		      _.each(users,function(user){
			    if(user.userName.toLowerCase().indexOf(req.params.userName.toLowerCase()) > -1){

			     var data={
	        			userName:user.userName,
	        			profilePic:user.profilePic,
	        			logo:user.logo,
	        			isFeatured:user.isFeatured,
	        			isBlocked:user.isBlocked,
	        			createdDate:user.createdDate,
	        			userId:user._id


        			}

					if(user.isFeatured==true){

	        			isFeaturedTrue.push(data)
        			}

					if((user.isFeatured==false) && (user.isBlocked==false) ){   //isFeatured is FALSE condition

	        			isFeaturedFalse.push(data)
        			}

					if(user.isBlocked==true ){

	        			isBlockedTrue.push(data)
        			}

					}
					userLen--;
					if(userLen<=0){

	        			var arrayRes=isFeaturedTrue.concat(isFeaturedFalse);
	        		    finalArray=arrayRes.concat(isBlockedTrue);
	        			var totalCount=finalArray.length;


	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {

                            finalArray[0].totalCount=totalCount;
                            var finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }

	        		}

			  })


        }
    })
})

//LIST USERS
router.get('/users/:limit', function (req, res) {

     var start=20;
        var limit=parseInt(req.params.limit);
		var finalArray=[];
        	var isFeaturedFalse=[];
        	var isFeaturedTrue=[];
        	var isBlockedTrue=[];
        	var isFlagedArr=[];

    db.User.find({isDeleted:false}).sort({_id:-1}).exec(function(err,users) {
        if(users==''){
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(users) + '}');
            res.send(message)
        } else {
		        var userLen=users.length;
				console.log("usrlleee"+userLen);
		      _.each(users,function(userdata){

			     var data={
	        			userName:userdata.userName,
	        			profilePic:userdata.profilePic,
	        			logo:userdata.logo,
	        			isFeatured:userdata.isFeatured,
	        			isBlocked:userdata.isBlocked,
	        			createdDate:userdata.createdDate,
	        			userId:userdata._id


        			}

					if(userdata.isFeatured==true) {

	        			isFeaturedTrue.push(data)


        			}

					if((userdata.isFeatured==false) && (userdata.isBlocked==false) ){   //isFeatured is FALSE condition

	        			isFeaturedFalse.push(data)
						//console.log("222222222"+ json.stringify(isFeaturedFalse));
        			}

					if(userdata.isBlocked==true) {

	        			isBlockedTrue.push(data)

						//console.log("33333333"+ json.stringify(isBlockedTrue));
        			}
					userLen--;
					if(userLen<=0){

	        			var arrayRes=isFeaturedTrue.concat(isFeaturedFalse);
	        		    finalArray=arrayRes.concat(isBlockedTrue);
	        			var totalCount=finalArray.length;

	        			console.log("totalcount"+totalCount);
	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {

                            finalArray[0].totalCount=totalCount;
                            var finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }

	        		}

			  })


        }
    })
})

router.get('/sortuser/:type/:limit',function (req, res) {

        var start=20;
        var limit=parseInt(req.params.limit);
		    var finalArray=[];
        	var isFeaturedFalse=[];
        	var isFeaturedTrue=[];
        	var isBlockedTrue=[];
        	var isFlagedArr=[];
	 if(req.params.type=="abc"){
    db.User.find({isDeleted:false}).sort({_id:-1}).exec(function(err,users) {
        if(users==''){
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(users) + '}');
            res.send(message)
        } else {
		        var userLen=users.length;
				console.log("usrlleee"+userLen);
		      _.each(users,function(userdata){

			     var data={
	        			userName:userdata.userName,
	        			profilePic:userdata.profilePic,
	        			logo:userdata.logo,
	        			isFeatured:userdata.isFeatured,
	        			isBlocked:userdata.isBlocked,
	        			createdDate:userdata.createdDate,
	        			userId:userdata._id


        			}

					if(userdata.isFeatured==true) {

	        			isFeaturedTrue.push(data)


        			}

					if((userdata.isFeatured==false) && (userdata.isBlocked==false) ){   //isFeatured is FALSE condition

	        			isFeaturedFalse.push(data)
						//console.log("222222222"+ json.stringify(isFeaturedFalse));
        			}

					if(userdata.isBlocked==true) {

	        			isBlockedTrue.push(data)

						//console.log("33333333"+ json.stringify(isBlockedTrue));
        			}
					userLen--;
					if(userLen<=0){

	        			var arrayRes=isFeaturedTrue.concat(isFeaturedFalse);
	        		    finalArray=arrayRes.concat(isBlockedTrue);
	        			var totalCount=finalArray.length;

	        			console.log("totalcount"+totalCount);
	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {

                            finalArray[0].totalCount=totalCount;
                             finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }

	        		}

			  })


        }
    })
	}

	else if(req.params.type=="date")
	{
	  db.User.find({isDeleted:false}).sort({createdDate:-1}).exec(function(err,users) {
        if(users==''){
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(users) + '}');
            res.send(message)
        } else {
		        var userLen=users.length;
				console.log("usrlleee2"+userLen);
		      _.each(users,function(userdata){

			     var data={
	        			userName:userdata.userName,
	        			profilePic:userdata.profilePic,
	        			logo:userdata.logo,
	        			isFeatured:userdata.isFeatured,
	        			isBlocked:userdata.isBlocked,
	        			createdDate:userdata.createdDate,
	        			userId:userdata._id
        			}

					 finalArray.push(data);
					userLen--;
					if(userLen<=0){
	        			var totalCount=finalArray.length;

	        			console.log("totalcount"+totalCount);
	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {

                            finalArray[0].totalCount=totalCount;
                             finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }
	        		}

			  })


        }
    })
	}

	else
	{
	  db.User.find({isDeleted:false}).sort({beatCount:-1}).exec(function(err,users) {
        if(users==''){
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(users) + '}');
            res.send(message)
        } else {
		        var userLen=users.length;
				console.log("usrlleee"+userLen);
		      _.each(users,function(userdata){

			     var data={
	        			userName:userdata.userName,
	        			profilePic:userdata.profilePic,
	        			logo:userdata.logo,
	        			isFeatured:userdata.isFeatured,
	        			isBlocked:userdata.isBlocked,
	        			createdDate:userdata.createdDate,
	        			userId:userdata._id


        			}

					 finalArray.push(data);


					userLen--;
					if(userLen<=0){


	        			var totalCount=finalArray.length;

	        			console.log("totalcount"+totalCount);
	        			if(finalArray==''){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
            				res.send(message);
                        } else {

                            finalArray[0].totalCount=totalCount;
                            finalArray=finalArray.slice(limit,start+limit);

	        			var message = JSON.parse('{"status":"success","message":' + JSON.stringify(finalArray) + '}');
                		res.send(message);
                        }

	        		}

			  })


        }
    })
	}
})


// Change password
router.put('/producers/:id/password', function (req, res) {
    db.User.findOne({email:req.body.email.toLowerCase()},function(err,user){
         if(user==undefined) {
            var message = JSON.parse('{"status":"failed","message":"The email you`ve entered doesn`t match any account."}');
            res.send(message)
        } else {
            bcrypt.genSalt(SALT_WORK_FACTOR, function (err, salt) {
                if (err) {
                    reject(err)
                } else {
                    bcrypt.hash(req.body.newPassword, salt, function (err, hash) {
                        if (err) {
                            reject(err)
                        }
                        else {
                            var hashPassword = hash;
                             bcrypt.compare(req.body.password, user.password, function (err, match) {
                                if(match){
                                    db.User.update({email:req.body.email}, {$set:{ password:hashPassword }},function(err,result){
                                        var message = JSON.parse('{"status":"success","message": "Your Password has been successfully changed!"}');
                                        res.send(message)
                                    })
                                } else {

                                    var message = JSON.parse('{"status":"failed","message":"The password you`ve entered doesn`t match."}');
                                    res.send(message)
                                }

                             })
                        }
                    })
                }
            })
        }
    })
})

//uPDATE fEATURED
router.put('/producers/updateFeatured/:id', function (req, res) {
    db.User.findOne({_id:req.params.id},function(err,user){
        if(user==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Producer was not found."}');
            res.send(message)
        }
        else {
            if(user.isBlocked==true){

                    db.User.update({_id:req.params.id}, {$set:{ isFeatured:req.body.isFeatured,isBlocked:false}},function(err,resultFeatured) {
                         db.User.findOne({_id:req.params.id},function(err,user1){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user1) + '}');
                        res.send(message)
                         })

                    })
                } else {
                    db.User.update({_id:req.params.id}, {$set:{ isFeatured:req.body.isFeatured}},function(err,result) {
                        db.User.findOne({_id:req.params.id},function(err,user1){
                            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user1) + '}');
                            res.send(message)
                        })
                })
            }

        }
    })
})

//UPDATE BLOCKED
router.put('/producers/updateBlocked/:id', function (req, res) {
    db.User.findOne({_id:req.params.id},function(err,user){
        if(user==undefined) {
            var message = JSON.parse('{"status":"failed","message":"Producer was not found."}');
            res.send(message)
        }
        else {
            if(user.isFeatured==true){

                    db.User.update({_id:req.params.id}, {$set:{ isBlocked:req.body.isBlocked,isFeatured:false}},function(err,resultBlocked) {
                        db.User.findOne({_id:req.params.id},function(err,user1){
                        var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user1) + '}');
                        res.send(message)
                     })
                    })


            } else {
                db.User.update({_id:req.params.id}, {$set:{ isBlocked:req.body.isBlocked}},function(err,result) {

                   db.User.findOne({_id:req.params.id},function(err,user1){
                        var message = JSON.parse('{"status":"success","message":' + JSON.stringify(user1) + '}');
                        res.send(message)
                     })
                })
            }
        }
    })
})

module.exports = router;
