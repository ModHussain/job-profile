var express = require('express');
var router = express.Router();
var db=require("../db.js");

var _ =require('underscore');
var nodemailer = require("nodemailer");
var sgTransport = require('nodemailer-sendgrid-transport');
var SENDGRID_USERNAME = "mybusinessapp";
var SENDGRID_PASSWORD = "hangten#12";

router.post('/addActivity',function (req, res) {
	var newActivity=new db.Activity({activity:req.body.activity, from:req.body.from})
	newActivity.save(function(err,activity){
		var message = JSON.parse('{"status":"success","message":' + JSON.stringify(activity) + '}');
        res.send(message)
	})
})

router.get('/listData/:limit',function (req, res) {
     var start=20;
     var limit=parseInt(req.params.limit);

      db.Activity.aggregate([
    {

        "$group": {
         "_id": {
            "$add": [
                { "$subtract": [
                    { "$subtract": [ "$createdDate", new Date(0) ] },
                    { "$mod": [
                        { "$subtract": [ "$createdDate", new Date(0) ] },
                        1000 * 60 * 60 * 24
                    ]}
                ]},
                new Date(0)
            ]
        },
        "viewCount": {
            "$sum": {
                "$cond": [ { "$eq": [ "$activity", "view" ] }, 1, 0 ]
            }
        },
        "playedCount": {
            "$sum": {
                "$cond": [ { "$eq": [ "$activity", "play" ] }, 1, 0 ]
            }
        },
		"beatsCount": {
            "$sum": {
                "$cond": [ { "$eq": [ "$activity", "beatSubmit" ] }, 1, 0 ]
            }
        },
		"usersCount": {
            "$sum": {
                "$cond": [ { "$eq": [ "$activity", "users" ] }, 1, 0 ]
            }
        },
    }}
]).exec(function(err,data) {
        if(data.length == 0){
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(data) + '}');
            res.send(message)
        } else {
		     var totalCount=data.length;
						data[0].totalCount=totalCount;
                        data=data.slice(limit,start+limit);
            var message = JSON.parse('{"status":"success","message":' + JSON.stringify(data) + '}');
            res.send(message)
        }
    })
})

router.post('/sendContactEmail', function(req,res){
    var userName=req.body.prodecureName;
	  var Email=req.body.email;
	  var Message=req.body.contactText;
	var options = {
		auth: {
			api_user: SENDGRID_USERNAME,
			api_key: SENDGRID_PASSWORD
		}
	}

		text='Hello,\n\n'+userName+'Contact you on Slapchart.com.\n\nHere are the details.\n\nName : '+userName+'\nEmail : '+Email+'\nMessage : '+Message+''

		var smtpTransport = nodemailer.createTransport(sgTransport(options));
		var mailOptions = {
			to: 'contact@slapchart.com',
			from: Email,
			subject: 'Contact Email',
			text:text

		};
		smtpTransport.sendMail(mailOptions, function (err) {
			if (err) {

			      var message = JSON.parse('{"status":"Failed","message":"Failed to send email."}');
                  res.send(message)

			}
			else {

			     var message = JSON.parse('{"status":"success","message":"Mail sent successfully."}');
                res.send(message)

				//resolve(user);
			}
		});
})

router.post('/sendFeedBack',function(req,res){
   	var Message=req.body.feedbackText;
	var options = {
		auth: {
			api_user: SENDGRID_USERNAME,
			api_key: SENDGRID_PASSWORD
		}
	}

		text='Hello,\n\n you recived  feedback on  Slapchart.com.\n\nHere are the details.\n\n Feedback : '+Message+''

		var smtpTransport = nodemailer.createTransport(sgTransport(options));
		var mailOptions = {
			to: 'feedback@slapchart.com',
			from: 'info@slapchart.com',
			subject: 'SlapChart Feedback',
			text:text
		};
		smtpTransport.sendMail(mailOptions, function (err) {
			if (err) {
				 var message = JSON.parse('{"status":"Failed","message":"Failed to send email."}');
                  res.send(message)
			}
			else {
			      var message = JSON.parse('{"status":"success","message":"Mail sent successfully."}');
                res.send(message)
			}
		});
})

module.exports = router;
