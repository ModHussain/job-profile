var express=require("express")
var app = express();
var bodyParser=require("body-parser");
var errorHandler=require('errorhandler');
var path = require('path');
var cron =require('cron');

var routes=require('./routes');
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser({limit: '500mb'}));

app.all('*', function (req, res, next) {
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Access-Control-Allow-Credentials', true);
    res.set('Access-Control-Allow-Methods', 'POST,GET,PUT,DELETE');
    res.set('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Authorization');
    if ('OPTIONS' == req.method) return res.send(200);
    next();
});

app.all('/*', routes.auth);

app.use(bodyParser({
    keepExtensions: true,
    uploadDir: __dirname + '/ Uploads'
}));
app.use(express.static(__dirname + '/public'));
// app.use('/public', express.static('./public'));
app.use('/forgotpassword/:id', express.static('public/forgotpassword.html'));
app.use(express.static(path.join(__dirname, 'Uploads')));

var cronJob = cron.job("*/10  * * * *", function(){
  console.info('cron job starting ' + new Date());
 routes.beats.cronjob;
})
cronJob.start();

//Routes
app.use('/api/producers',routes.users);
app.use('/api/activities',routes.activities);
app.use('/api/beats',routes.beats);
app.use(errorHandler);

// BY USING 9016 PORT NUMBER TO GET THE RESULT ON THE BROWSER
var server = app.listen(9014,function()
{
    var host = server.address().address
    var port = server.address().port
    console.log('app running at host', port)
});
