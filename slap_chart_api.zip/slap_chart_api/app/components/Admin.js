import React from 'react';
import Header from './Header';
import { PropTypes } from 'react-router';

class Admin extends React.Component {

	constructor(props) {
        super(props)
        this.state = {

        };
    }



   render() {
      return (

	      <div className="body">
	        <div className="container-fluid" style={{padding: 0}}>
                      <Header />

                     {this.props.children}
         </div>
			 </div>
      );
   }
}


Admin.contextTypes = { history: PropTypes.history }
export default Admin;
