var mongoose = require('mongoose');
var config = require('./config')

exports.mongoose=mongoose;
var mongodbURL = config.dbUrl;
var mongodbOptions = {};
var Schema = mongoose.Schema;

mongoose.connect(mongodbURL, mongodbOptions, function (err, res) {
    if (err) {
        console.log('Connection refused to ' + mongodbURL);
        console.log(err);
    }
    else {
        console.log('Connection successful to: ' + mongodbURL);
    }
});



// User Schema
var UserSchema = new Schema({

    userName: {
        type:String
    },
    email:{
        type:String,
        trim: true,
        match: /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,
        required:true
    },
    password:{
        type:String,
        required:true,
        trim: true
    },
    contactEmail:{
        type:String,
        trim: true,
        match: /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/
    },

    cloudUri:{
        type:String
    },

    twitterUri:{
        type:String
    },
    isProfileUpdate:{
        type:Boolean,
        default:false
    },
    facebookUri:{
        type:String
    },

    instagramUri:{
        type:String
    },

    homeUri:{
        type:String
    },

    profilePic:{
        type:String
    },

    logo:{
        type:String
    },

    lastLogin:{
        type:Date
    },

    isBlocked:{
        type:Boolean,
        default:false
    },
    isDeleted:{
        type:Boolean,
        default:false,
        required:true
    },

    createdDate:{
        type:Date,
        default:Date.now,
        required:true
    },

    modifiedDate:{
        type:Date,
        default:Date.now,
        required:true
    },
    submittedBeats:{    /////
        type:Number
    },
    selectedBeats:{     /////
        type:Number
    },
    role:{
        type:String
    },

    isFeatured:{
        type:Boolean,
        default:false
    },

    status:{
        type:String
    },

    flagColorCode:{
        type:String
    },
	beatCount:{
        type:Number,default:0
    }

})

exports.User = mongoose.model('User', UserSchema, 'users');

// Beats Schema
var BeatSchema = new Schema({

    userId:{
        type: String
    },
    title:{
        type: String
    },
    media:{
        type: String
    },

    mediaSource:{
        type: String
    },
    status:{
        type: String
    },

    publishedDate:{
        type:Date,
        default:Date.now,
        required:true
    },
    queuedDate:{
        type:Date
    },
    isDeleted:{
        type: Boolean
    },
    isFlaged:{
        type: Boolean,
        default:false
    },
    flagedUserId:{
        type: String
    },
    flagedDate:{
        type: Date
    },
    createdDate:{
        type:Date,
        default:Date.now,
        required:true
    },
    modifiedDate:{
        type:Date,
        default:Date.now,
        required:true
    }
})

exports.Beat = mongoose.model('Beat', BeatSchema, 'beats')

// Activity Schema
var ActivitySchema = new Schema({

    activity:{
        type: String
    },
    from:{
        type: String
    },
    createdDate:{
        type:Date,
        default:Date.now,
        required:true
    },
    modifiedDate:{
        type:Date,
        default:Date.now,
        required:true
    }
})

exports.Activity = mongoose.model('Activity', ActivitySchema, 'acitvities');

//Message Schema
var MessageSchema = new Schema({

    subject:{
        type: String
    },
    message:{
        type: String
    },
    fromUserId:{
        type: String
    },
    toUserId:{
        type: String
    },
    createdDate:{
        type:Date,
        default:Date.now,
        required:true
    }
})

exports.Message = mongoose.model('Message', MessageSchema, 'messages');


/*var User = mongoose.model('User', UserSchema);
var Beats = mongoose.model('Beats', BeatSchema);
var Message = mongoose.model('Message', MessageSchema);
var Activity = mongoose.model('Activity', ActivitySchema);

module.exports.User = User;
module.exports.Beats = Beats;
module.exports.Message = Message;
module.exports.Activity = Activity;*/



//module.exports = userModel;
//module.exports = postModel;
